
package haas_classesextended;

import java.awt.Color;
import java.util.ArrayList;

/*
author: Jake Haas
Created: November 14, 2018

Description: 

    This program generates 50 random shapes, they are either Rectangles, Circles, or Custom polygons(random shapes),
    it then prints the number of verticies, the number of sides, perimeter, x-y position, and area of each shape. The shapes are
    then put into a graphical environment where they move and wrap around the screen while being affected by moving white gravity points.

*/

public class Haas_ClassesExtended {

    // a constant array to hold 50 shapes
    public static Shape[] shapes = new Shape[50];
    
    // a contsant array to hold every gravity point
    public static GravityPoint[] gravityPoints = new GravityPoint[(int)(Math.random()*3)+1];
    
    public static void main(String[] args) {
        
        // initializes the window for graphics
        Window.init();
        
        Circle c = new Circle(60, 60, 10, new Vector(80, 90));
        
        // generates 50 random shapes and loads them into an array
        generateShapes();
        
        // generates the gravity points
        generateGravityPoints();
        
        // sets the random shapes to a random color
        setRandomShapeColors();
        
        // prints the toString() of every shape to the console
        for (Shape s: shapes) {
            System.out.println(s + "\n\n");
        }
        
        // runs the grapics loop
        graphicsLoop();
        
    }
    
    public static void graphicsLoop(){
        // while the program is running(closing window stops this loop)
        while (true){
            // sets the frame rate to 60fps
            tick();
            
            // paints the background black
            Window.getContext().setColor(new Color(0, 0, 0));
            Window.getContext().fillRect(0, 0, Window.getFrame().getWidth(), Window.getFrame().getHeight());
            
            // draws gravity points, and moves them
            for (GravityPoint p: gravityPoints) {
                p.draw();
                p.update();
            }
            
            // for every shape
            for (Shape s: shapes) {
                // draw outline of shape
                s.drawOutline();
                // update the position of shape
                s.update();
                // for every gravity point
                for (GravityPoint gp: gravityPoints){
                    // push shape towards the gravity point
                    s.addVector(gp.getForceToShape(s));
                }
                // rotates the shape depending on its velocity
                s.rotateBy(s.getVelocity().getMagnitude()/100);
            }
            // repaints the JFrame
            Window.paint();
        }
    }
    
    // holds when the last frame began
    private static long startTime = System.currentTimeMillis();
    public static void tick(){
        
        // target frames per second
        final int FPS = 60;
        // how many milliseconds that fps leaves between frames
        final long BETWEEN_FRAMES = 1000/FPS;
        
        // if this frame is running to fast wait the difference
        if (System.currentTimeMillis() - startTime <= BETWEEN_FRAMES){
            try {
                Thread.sleep(BETWEEN_FRAMES - (System.currentTimeMillis() - startTime));
            } catch (Exception e){}
        }
        // set when this frame began
        startTime = System.currentTimeMillis();
        
        // run heavy opperations after calling this method to include in frame time
    }
    
    private static void generateShapes(){
        // declare variables that are randomized for every shape
        int type;
        double randomX;
        double randomY;
        Vector randomVelocity;

        double randomLength;
        Point[] points;
        double pointAngleOffset; 
        double pointX, pointY;
        
        // for 50 shapes
        for (int i = 0; i < 50; i++){
            // set the type to either 0 for circle, 1 for rectangle, and 2 for custom polygon
            type = (int)(Math.random()*3);
            
            // create array for custom polygon verticies
            points = new Point[(int)((Math.random()*5)+3)];
            // create how many radians apart each verticy will be for custom polygons
            pointAngleOffset = (Math.PI*2) / points.length; 
            
            // create random x, y coordinates
            randomX = Math.random() * Window.getFrame().getWidth();
            randomY = Math.random() * Window.getFrame().getHeight();
            
            // create random velocity vector(magnitude and direction)
            randomVelocity = new Vector((Math.random() * 0)+5, Math.random() * Math.PI * 2);
            
            // decide which type of shape to add
            switch (type) {
                case 0:
                    // add circle with random properties
                    shapes[i] = new Circle(randomX, randomY, (Math.random() * 50) + 30, randomVelocity);
                    break;
                case 1:
                    // add rectangle with custom properties
                    shapes[i] = new Rectangle(randomX, randomY, (Math.random() * 40) + 30, (Math.random() * 40) + 30, randomVelocity);
                    break;
                case 2:
                    // add custom polygon
                    
                    // creates verticies by calculating location of a point using a random radius and incremental angle
                    for (int pointI = 0; pointI < points.length; pointI++){
                        randomLength = (Math.random()*50)+30;
                        pointX = (Math.cos(pointAngleOffset*pointI+Math.random()*pointAngleOffset/2) * randomLength)+randomX;
                        pointY = (Math.sin(pointAngleOffset*pointI) * randomLength)+randomY;
                        points[pointI] = new Point(pointX, pointY);
                    }
                    
                    // create shape and add it to the shape array
                    shapes[i] = new Polygon(randomX, randomY, points, randomVelocity);
                    break;
            }
            
        }
    }
    
    public static void setRandomShapeColors(){
        
        // declare variable to hold color
        Color randomColor;
        
        // declare variables to hold red, green, and blue values that make the color
        int red, green, blue;
        
        // holds the primary color base
        int colorNum;
        
        // for every shape
        for (Shape s: shapes){
            // set colors to black
            red = 0;
            green = 0;
            blue = 0;
            colorNum = (int)(Math.random()*3);
            
            // sets primary color to a value of 255
            switch(colorNum){
                case 0:
                    red = 255;
                    break;
                case 1:
                    green = 255;
                    break;
                case 2:
                    blue = 255;
                    break;
            }
            
            // sets one value other than the primary color to a value between 0 and 255
            if (red == 255){
                if (Math.random() > 0.5){
                    green = (int)(Math.random() * 255);
                } else {
                    blue = (int)(Math.random() * 255);
                }
            } else if (green == 255){
                if (Math.random() > 0.5){
                    red = (int)(Math.random() * 255);
                } else {
                    blue = (int)(Math.random() * 255);
                }
            } else if (blue == 255) {
                if (Math.random() > 0.5){
                    red = (int)(Math.random() * 255);
                } else {
                    green = (int)(Math.random() * 255);
                }
            }
            
            // sets random color to the color with generated values
            randomColor = new Color(red, green, blue);
            
            // sets the shape color to random color
            s.setColor(randomColor);
        }
        
    }
    
    public static void generateGravityPoints(){
        
        // holds randomly generated x, y position and mass
        double randomX;
        double randomY;
        double randomMass;
        
        for (int i = 0; i < gravityPoints.length; i++){
            // for every spot in the gravityPoint array fill it with a random gravity point
            randomX = Math.random()*Window.getFrame().getWidth();
            randomY = Math.random()*Window.getFrame().getHeight();
            randomMass = (Math.random()*80)+50;
            gravityPoints[i] = new GravityPoint(new Point(randomX, randomY), randomMass);
        }
    }
}

class GravityPoint {
    
    // declare position
    private Point point;
    
    // declare mass to determine gravitational pull
    private double mass;
    
    // gravitational constant determines general strength of gravity
    private static double G = 0.03;
    
    // declare velocity
    Vector velocity;
    
    public GravityPoint(Point p, double _mass){
        // contructor takes position and mass then stores it
        point = p;
        mass = _mass;
        
        // velocity is in random direction and magnitude
        velocity = new Vector(Math.random()*1, Math.random()*Math.PI*2);
    }
    
    public Point getPoint(){
        // getter function for position
        return point;
    }
    
    public Vector getForceToShape(Shape s){
        // declare magnitude and direction of pulling force
        double magnitude;
        double direction;
        double m = 1000;
        
        // calculate delta x and y
        double xDiff = point.getX() - s.getXPos();
        double yDiff = point.getY() - s.getYPos();
        
        // calculate distance to the shape
        double radius = Math.sqrt(xDiff*xDiff + yDiff*yDiff);
        
        // calculate the angle to the shape
        direction = Vector.getAngleFromComps(xDiff, yDiff);
        
        // if the shape is more than 60 pixels away it is affected by gravity, this prevents gravity equation from producing extremly large values
        if (radius > 60) magnitude = Math.abs(G *((mass*m)/(radius*radius)));
        else magnitude = 0;
        
        // returns the resulting gravity vector
        return new Vector(magnitude, direction);
    }
    
    public void draw(){
        // defines the radius to draw the gravity point
        double radius = mass*mass*0.013;
        
        // integer represents the grayscale value of the current Graphics color
        int color;
        
        // draws circles that decrease in radius and increae in grayscale value to represent gravity point
        for (int i = 0; i < 100; i ++){
            radius *= 0.9;
            color = i*i;
            if (color < 0) color = 0;
            if (color > 255) color = 255;
            Window.getContext().setColor(new Color(color, color, color));
            Window.getContext().fillOval((int)(point.getX() - radius/2), (int)(point.getY() - radius/2), (int)radius, (int)radius);
        }
    }
    
    public double getMass(){
        // getter/accessor method for mass
        return mass;
    }
    
    public Vector getVelocity(){
        // getter/accessor method for velocity
        return velocity;
    }
    
    public void setMass(double _mass){
        mass = _mass;
    }
    
    public void setVelocity(Vector _velocity){
        velocity = _velocity;
    }
    
    public void update(){
        // wraps around the screen, moves based on velocity
        point = new Point(point.getX()+velocity.getXcomp(), point.getY() + velocity.getYcomp());
        if (point.getX() > Window.getFrame().getWidth() + 10) point.setX(-10);
        if (point.getX() < -10) point.setX(Window.getFrame().getWidth() + 10);
        
        if (point.getY() > Window.getFrame().getHeight() + 10) point.setY(-10);
        if (point.getY() < -10) point.setY(Window.getFrame().getHeight() + 10);
    }
    
}