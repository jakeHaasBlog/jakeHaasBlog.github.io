
package haas_classesextended;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Window extends JFrame {
    
    private static BufferedImage frame;
    private static Graphics context;
    private static Window window;
    private static Panel graphicsPanel;
    
    public Window(){
        setTitle("Classes Extended");
        setSize(1300, 700);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        frame = new BufferedImage(getWidth(), getHeight(), BufferedImage.TYPE_INT_RGB);
        context = frame.getGraphics();
        graphicsPanel = new Panel();
        add(graphicsPanel);
    }
    
    public static void init(){
        window = new Window();
    }
    
    public static Graphics getContext(){
        return context;
    }
    
    public static void paint(){
        window.repaint();
    }
    
    public static Window getFrame(){
        return window;
    }
    
    private class Panel extends JPanel{
        
        public Panel(){
            setVisible(true);
        }
        
        public void paint(Graphics g){
            g.drawImage(frame, 0, 0, null);
        }
    }
    
}
