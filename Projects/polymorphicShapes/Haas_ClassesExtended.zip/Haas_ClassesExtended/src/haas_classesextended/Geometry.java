
package haas_classesextended;

import java.awt.Color;

/*

Author: Jake Haas
Date created: Nov 15, 2018

decription: This file contains shape class hierarchy in addition to utility classes for
    calculating geometric properties such as tri for triangles(mainly area), Point class for holding
    x, y positions intuitively, and rotating points about other points, and Vector class for velocities and forces.

*/

interface Shape {
    
    // methods all shapes must implement
    
    public double area();

    public double perimeter();

    public double getXPos();

    public double getYPos();
    
    public Point[] getVerticies();
    
    public Vector getVelocity();
    
    public void addVector(Vector v);
    
    public void drawOutline();
    
    public void setVerticies(Point[] points);

    public void move(double xLoc, double yLoc);
    
    public void moveX(double x);
    
    public void moveY(double y);
    
    public void setColor(Color _color);
    
    public void update();
    
    public void rotateBy(double r);
    
    public Shape clone();
    
    public boolean equals(Shape s);
    
    public Color getColor();

    // toString is already implemented in java and does not need to be redeclared in shape interface
}

abstract class AbstractShape implements Shape {

    @Override
    public abstract Shape clone();
    
    // holds x and y position
    protected double xPosition, yPosition;
    
    // hold velocity
    protected Vector velocity;
    
    // holds all the verticies that make up the shape
    protected Point[] verticies;
    
    // holds the color of the shape, default white
    protected Color color = new Color(255, 255, 255);
    
    // contructor takes verticies, x, y, of the middle, and velocity and sets internal variables
    public AbstractShape(double x, double y, Point[] _verticies, Vector _velocity){
        xPosition = x;
        yPosition = y;
        velocity = _velocity;
        verticies = _verticies;
    }
    
    @Override
    public double area(){
        // holds total area of shape
        double area = 0;
        
        // temporary triangle object used to get area
        Tri innerTriangle;
        
        // converts the veritcies into triangles that connect to the middle of the shape(xPosition, yPosition)
        for (int i = 0; i < verticies.length; i++){
            if (i < verticies.length-1){
                // create triangle
                innerTriangle = new Tri(verticies[i], verticies[i+1], new Point(xPosition, yPosition));
                // triangle has method for calculating area, adds it to total area
                area += innerTriangle.area();
            } else {
                // the last triangle connects back to the first point
                
                // create triangle
                innerTriangle = new Tri(verticies[i], verticies[0], new Point(xPosition, yPosition));
                // triangle has method for calculating area, adds it to total area
                area += innerTriangle.area();
            }
        }
        
        return area;
    }

    @Override
    public double perimeter(){
        // holds total perimeter
        double perimeter = 0;
        
        // holds length of the current line segment
        double lineSegment;
        
        // holds delta x and delta y
        double xDiff, yDiff;
        
        // create line segments out of verticies and add their length to perimeter
        for (int i = 0; i < verticies.length; i++){
            if (i < verticies.length-1){
                // calculate delta x, and delta y
                xDiff = Math.abs(verticies[i].getX() - verticies[i+1].getX());
                yDiff = Math.abs(verticies[i].getY() - verticies[i+1].getY());
                // turn delta x and delta y into a line
                lineSegment = Math.sqrt(xDiff*xDiff + yDiff*yDiff);
                // add line to perimeter
                perimeter += lineSegment;
            } else {
                // the last line must connect back to the first verticy
                
                // calculate delta x, and delta y
                xDiff = Math.abs(verticies[i].getX() - verticies[0].getX());
                yDiff = Math.abs(verticies[i].getY() - verticies[0].getY());
                // turn delta x and delta y into a line
                lineSegment = Math.sqrt(xDiff*xDiff + yDiff*yDiff);
                // add line to perimeter
                perimeter += lineSegment;
            }
        }
        
        return perimeter;
    }

    @Override
    public double getXPos(){
        // returns the x-position to the center of this shape
        return xPosition;
    }

    @Override
    public double getYPos(){
        // return the y-position of the center of this shape
        return yPosition;
    }

    @Override
    public void move(double xLoc, double yLoc){
        // translates the xPosition, yPosition(origin/center) and all the verticies
        
        // find delta x and y
        double xDiff = xLoc - xPosition;
        double yDiff = yLoc - yPosition;
        for (Point p: verticies){
            // for all points add delta x and y
            p.setX(p.getX() + xDiff);
            p.setY(p.getY() + yDiff);
        }
        // set the origin to inputed x, y position
        xPosition = xLoc;
        yPosition = yLoc;
    }
    
    @Override
    public Point[] getVerticies(){
        // returns verticies
        return verticies;
    }
    
    @Override
    public Vector getVelocity(){
        // returns velocity
        return velocity;
    }
    
    @Override
    public void addVector(Vector v){
        // adds a vector to the velocity
        velocity.addVector(v);
    }
    
    @Override
    public void setVerticies(Point[] points){
        // sets verticies to input verticies
        verticies = points.clone();
    }
    
    @Override
    public void drawOutline(){
        // sets the graphics color to stored color
        Window.getContext().setColor(color);
        
        // connects every verticy with a line in order
        for (int i = 0; i < verticies.length; i++){
            if (i < verticies.length - 1) Window.getContext().drawLine((int)verticies[i].getX(), (int)verticies[i].getY(), (int)verticies[i+1].getX(), (int)verticies[i+1].getY());
            // last line must connect back to the first verticy
            else Window.getContext().drawLine((int)verticies[i].getX(), (int)verticies[i].getY(), (int)verticies[0].getX(), (int)verticies[0].getY());
        }
    }
    
    @Override
    public void setColor(Color _color){
        // setter method for the color
        color = _color;
    }
    
    @Override
    public void update(){
        
        // wraps the shape around the screen when it is 700 pixels away from the edge
        if (xPosition > Window.getFrame().getWidth() + 700) {
            move(-700, yPosition);
        } else if (xPosition < -700) {
            move(Window.getFrame().getWidth() + 700, yPosition);
        }
        
        if (yPosition > Window.getFrame().getHeight() + 700) {
            move(xPosition, -700);
        } else if (yPosition < -700) {
            move(xPosition, Window.getFrame().getHeight() + 700);
        }
        
        // moves the shape based on velocity
        moveX(velocity.getXcomp());
        moveY(velocity.getYcomp());
    }
    
    @Override
    public void moveX(double byX){
        // moves the shape in the x axis
        for (Point p: verticies) p.setX(p.getX() + byX);
        xPosition += byX;
    }
    
    @Override
    public void moveY(double byY){
        // moves the shape in the y axis
        for (Point p: verticies) p.setY(p.getY() + byY);
        yPosition += byY;
    }
    
    @Override
    public void rotateBy(double r){
        // rotates the shape by a certain degree around the middle of the shape(xPosition, yPosition)
        for (Point p: verticies) p.rotateAboutPoint(new Point(xPosition, yPosition), r);
    }
    
    @Override
    public Color getColor(){
        return color;
    }
    
    @Override
    public boolean equals(Shape s){
        
        // hold if equal
        boolean isEqual = true;
        
        // if the number of verticies is the same
        if (s.getVerticies().length == getVerticies().length){
            // for every verticy if the other shape does not have the same verticy and position in same index isEaual = false
            for (int i = 0; i < getVerticies().length; i++){
                if (s.getVerticies()[i].getX() != getVerticies()[i].getX()){
                    isEqual = false;
                }
                if (s.getVerticies()[i].getY() != getVerticies()[i].getY()){
                    isEqual = false;
                }
            }
        } else {
            // verticies not the same length
            isEqual = false;
        }
        
        // if x,y of origin/middle is not the same isEqual = false
        if (xPosition != s.getXPos()) isEqual = false;
        if (yPosition != s.getYPos()) isEqual = false;
        
        // if colors are not the same it is not the same shape
        if (color != s.getColor()) isEqual = false;
        
        // if the magnitude and direction of velocity are different it is not the same shape
        if (velocity.getMagnitude() != s.getVelocity().getMagnitude()) isEqual = false;
        if (velocity.getDirection() != s.getVelocity().getDirection()) isEqual = false;
        
        // class types must be the same, otherwise they are not the same shape
        if (s.getClass() != getClass()) isEqual = false;
        
        // return final decision about equality
        return isEqual;
    }
    
    @Override
    public abstract String toString();
}

class Circle extends AbstractShape {
    
    // holds the radius value
    protected double radius;
    public Circle(double x, double y, double _radius, Vector _velocity){
        // calls the constructor for abstract shape
        super(x, y, initialPoints(x, y, _radius), _velocity);
        
        // sets radius to input radius
        radius = _radius;
    }
    
    private static Point[] initialPoints(double x, double y, double radius){
        // initializes the points that make up the circumference of the circle
        
        // resolution determines number of verticies that cover the circumference(5 will make a pentagon, 6 will make a hexagon, 7 will make a heptagon...)
        int resolution = (int)(Math.random()*4 + 3);
        
        // calculates the angle measure between each verticy to evenly space verticies
        double angleChange = Math.PI*2 / (double)resolution;
        
        // creates array to hold verticies
        Point[] points = new Point[resolution];
        
        // for every point to be created
        for (int i = 0; i < resolution; i++){
            // create a point in the array in circle around center
            points[i] = new Point(x + Math.cos(angleChange*i)*radius, y + Math.sin(angleChange*i)*radius);
        }
        
        // returns generated verticies
        return points;
    }
    
    @Override
    public String toString(){
        // toString includes the area and circumference of a perfect circle with the same radius and the actual circumference and area defined by verticies
        return "CIRCLE\n" 
                +"Radius: " + radius + "\n"
                +"(x, y) Position: ("+ xPosition +", "+ yPosition +")\n"
                +"Area of internal shape: "+ area() +"\n"
                +"Area of outlining circle: "+ Math.PI*radius*radius +"\n" // area = PI r squared
                +"Perimeter of internal shape: "+ perimeter() +"\n"
                +"Perimeter of outlining circle: "+ 2*Math.PI*radius +"\n";
    }
    
    @Override
    public Circle clone(){
        // creates a new circle at same position with same radius and velocity
        Circle c =  new Circle(getXPos(), getYPos(), radius, velocity);
        // verticies are randomly generated in constructor and must be set manually
        c.setVerticies(verticies);
        // sets new circle to the same color
        c.setColor(color);
        // returns clone
        return c;
    }
    
    @Override
    public void drawOutline(){
        // draws an outline around the circle and the shape inside of the circle
        
        // sets the color to held color
        Window.getContext().setColor(color);
        
        // draws a circle around the x, y position with the held radius
        Window.getContext().drawOval((int)(getXPos() - radius), (int)(getYPos() - radius), (int)radius*2, (int)radius*2);
        
        // calls the super class method which draws lines between all verticies
        super.drawOutline();
    }
    
}

class Rectangle extends AbstractShape {
    
    // holds a width and height value
    protected double width, height;
    public Rectangle(double x, double y, double _width, double _height, Vector _velocity){
        // calls the superclass constructor
        super(x, y, generateVerticies(x, y, _width, _height), _velocity);
        // sets the width and height to input values
        width = _width;
        height = _height;
    }
    
    private static Point[] generateVerticies(double x, double y, double width, double height){
        // generates the verticies at each corner of the rectangle and adds them to the point array
        Point[] points = new Point[4];
        points[0] = new Point(x - width/2, y - height/2);
        points[1] = new Point(x - width/2, y + height/2);
        points[2] = new Point(x + width/2, y + height/2);
        points[3] = new Point(x + width/2, y - height/2);
        // returns the point array
        return points;
    }
    
    @Override
    public double perimeter(){
        // calculates the perimeter based on width and height values
        return width*2 + height*2;
    }
    
    @Override
    public double area(){
        // calculates area based on the width and height values
        return width * height;
    }
    
    @Override
    public String toString(){
        // returns string of width, height, position, area, and perimeter
        return "RECTANGLE\n" 
                +"Width: "+ width + "\n"
                +"Height: "+ height + "\n"
                +"(x, y) Position: ("+ xPosition +", "+ yPosition +")\n"
                +"Area: "+ area() +"\n"
                +"Perimeter: "+ perimeter();
    }
    
    // clone and equals are already implemented internally
    
    @Override
    public Rectangle clone(){
        // returns new rectangle identical to this one
        Rectangle r = new Rectangle(getXPos(), getYPos(), width, height, velocity);
        r.setColor(color);
        r.setVerticies(verticies);
        return r;
    }
    
}

class Polygon extends AbstractShape {
    
    public Polygon(double _x, double _y, Point[] _verticies, Vector _velocity){
        // polygons only take constructor arguments
        super(_x, _y, _verticies, _velocity);
    }

    @Override
    public String toString() {
        // returns a string containing the number of verticies, number of sides, position, perimeter, and area based solely on verticies
        return "CUSTOM POLYGON\n"+
                "Number of verticies: "+ verticies.length +"\n"+
                "Number of sides: "+ verticies.length +"\n"+
                "(x, y) Position: ("+ xPosition +", "+ yPosition +")\n"+
                "Perimeter: "+ perimeter() +"\n"+
                "Area: "+ area();
    }
    
    @Override
    public Polygon clone(){
        // returns a copy of this polygon
        Polygon poly = new Polygon(getXPos(), getYPos(), verticies, velocity);
        poly.setColor(color);
        return poly;
    }
    
}

class Point {
    // holds an x, y position
    private double x, y;
    public Point(double _x, double _y){
        x = _x;
        y = _y;
    }
    public void setX(double _x){
        // sets the x value to input value
        x = _x;
    }
    public void setY(double _y){
        // sets the y value to input value
        y = _y;
    }
    public double getX(){
        // returns x value
        return x;
    }
    public double getY(){
        // return y value
        return y;
    }
    public void setPosition(double _x, double _y){
        // sets the x and y values to input values
        x = _x;
        y = _y;
    }
    public void rotateAboutPoint(Point p, double angle){
        // sets this point's x to the origin(0, 0) + the point to rotate about
        x -= p.x;
        y -= p.y;

        // hold the new x and y coordinates seperately
        double newPx, newPy;
        
        // calculate where the rotated point should go
        newPx = x*Math.cos(angle) - y*Math.sin(angle);
        newPy = x*Math.sin(angle) + y*Math.cos(angle);

        // sets the new x and y coordinates back to where it was before it was translated to the origin
        x = newPx + p.x;
        y = newPy + p.y;
    }
    
}

class Vector {
    
    // vectors are values that have a magnitude and direcition (we use them in SPH4U)
    private double magnitude;
    private double direction;
    
    public Vector(double _magnitude, double _direction){
        // sets internal variables to input
        magnitude = _magnitude;
        direction = _direction;
    }
    
    public double getMagnitude(){
        // getter method for magnitude
        return magnitude;
    }
    
    public double getDirection(){
        // getter method for direction
        return direction;
    }
    
    public void setMagnitude(double mag){
        // mutator method for magnitude
        magnitude = mag;
    }
    public void setDirection(double dir){
        // mutator method for direction
        direction = dir;
    }
    
    public double getXcomp(){
        // returns the x-component of this vector
        return Math.cos(direction) * magnitude;
    }
    
    public double getYcomp(){
        // returns the y-component of this vector
        return Math.sin(direction) * magnitude;
    }
    
    /** Breaks down the x and y components of this vector and the input vector, then adds them together and redefines this vector accordingly */
    public void addVector(Vector vect){
        
        // holds the resulting x and y components
        double resultantX = vect.getXcomp() + getXcomp();
        double resultantY = vect.getYcomp() + getYcomp();
        
        // finds the angle the resulting x and y components have between eachother
        double angle = getAngleFromComps(resultantX, resultantY);
        
        // calculates the resulting magnitude from adding vectors using the pythagorean theorum
        float totalMagnitude = (float)Math.sqrt(resultantX*resultantX + resultantY*resultantY);
        
        // sets the magnitude and direction to new calculated values
        magnitude = totalMagnitude;
        direction = angle;
    }
    
    /** Returns the angle between a x-component and y-component, this method is static and can be used anywhere */
    public static double getAngleFromComps(double xComp, double yComp){
        // holds the angle
        float angle;
        // if the x-component is negitive PI(or 180 degrees) must be added to arctangent of components, else just use arctangent
        if (xComp < 0){
            angle = (float)(Math.atan(yComp/xComp) + Math.PI);
        } else {
            angle = (float)(Math.atan(yComp/xComp));
        }
        // returns the calculated angle
        return angle;
    }
}

class Tri {
    // holds the three verticies of the triangle
    Point one, two, three;
    
    public Tri (Point _one, Point _two, Point _three){
        // sets stored points to input points
        one = _one;
        two = _two;
        three = _three;
    }
    
    /** returns the area of this triangle */
    public double area(){
        
        // finds the distance between the first and second points as x, y components
        double xDiff = (one.getX() - two.getX());
        double yDiff = (one.getY() - two.getY());
        
        // use the pythagorean theorum to find distance between first and second point
        double lengthB = Math.sqrt(xDiff*xDiff + yDiff*yDiff);
        
        
        // finds the distance between the second and third points as x, y components
        xDiff = (two.getX() - three.getX());
        yDiff = (two.getY() - three.getY());
        
        // use the pythagorean theorum to find distance between second and third point
        double lengthA = Math.sqrt(xDiff*xDiff + yDiff*yDiff);
        
        
        // finds the distance between the third and first points as x, y components
        xDiff = (three.getX() - one.getX());
        yDiff = (three.getY() - one.getY());
        
        // use the pythagorean theorum to find distance between third and first point
        double lengthC = Math.sqrt(xDiff*xDiff + yDiff*yDiff);
        
        
        // calculates angle BAC(points 2, 1, 3), using the cosine law
        double thetaA = Math.acos(((lengthB*lengthB) + (lengthC*lengthC) - (lengthA*lengthA))/(2*lengthB*lengthC));
        
        // calculates the height of the triangle using primary trig ratios
        double height = Math.sin(thetaA) * lengthC;
        
        // returns the area of the triangle(length * height / 2)
        return lengthB * height / 2;
    }
}