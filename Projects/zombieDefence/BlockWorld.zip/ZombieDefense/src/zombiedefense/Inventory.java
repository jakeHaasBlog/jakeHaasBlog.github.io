
package zombiedefense;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

public class Inventory {
    
    int x = 20, y = 20;
    int selected = 1;
    public ItemBox inventory[][] = new ItemBox[10][5];
    public static final BufferedImage BOX_IMAGE = FileReader.getImage("itemBox.png", ItemBox.width, ItemBox.height);
    public static final int INVENTORY_WIDTH = (int)(ZombieDefense.window.getWidth() / 1.5);
    public static final int INVENTORY_HEIGHT = (int)(ZombieDefense.window.getHeight() / 1.5);
    
    public boolean showFull = false;
    
    public Inventory(){
        for (int x = 0; x < inventory.length; x++){
            for (int y = 0; y < inventory[0].length; y++){
                inventory[x][y] = new ItemBox(x, y);
            }
        }
    }
    
    private boolean eWasDown = false;
    private boolean mouseWasDown = false;
    private boolean holdingBlocks = false;
    private ItemBox holdingBox;
    public void update(){
        
        if (Window.keysDown[69]){
            if (!eWasDown) showFull = !showFull;
            eWasDown = true;
        } else {
            eWasDown = false;
        }
        if (Window.keysDown[49]) selected = 1;
        if (Window.keysDown[50]) selected = 2;
        if (Window.keysDown[51]) selected = 3;
        if (Window.keysDown[52]) selected = 4;
        if (Window.keysDown[53]) selected = 5;
        if (Window.keysDown[54]) selected = 6;
        if (Window.keysDown[55]) selected = 7;
        if (Window.keysDown[56]) selected = 8;
        if (Window.keysDown[57]) selected = 9;
        if (Window.keysDown[48]) selected = 10;
        
        if (!mouseWasDown){
            if (Window.mouseDown){
                if (showFull){
                    Rectangle boxRect;
                    for (int boxX = 0; boxX < inventory.length; boxX++){
                        for (int boxY = 0; boxY < inventory[0].length; boxY++){
                            boxRect = new Rectangle(inventory[boxX][boxY].pixelX, inventory[boxX][boxY].pixelY, ItemBox.width, ItemBox.height);
                            if (boxRect.contains(new Point(Window.mouseX, Window.mouseY))){
                                if (inventory[boxX][boxY].itemType != 0){
                                    holdingBox = inventory[boxX][boxY];
                                    holdingBlocks = true;
                                    selected = 0;
                                }
                            }
                        }
                    }
                }
            } 
        }
        if (mouseWasDown){
            if (!Window.mouseDown){
                holdingBlocks = false;
                selected = 1;
                
                Rectangle boxRect;
                for (int boxX = 0; boxX < inventory.length; boxX++){
                    for (int boxY = 0; boxY < inventory[0].length; boxY++){
                        try{
                            boxRect = new Rectangle(inventory[boxX][boxY].pixelX, inventory[boxX][boxY].pixelY, ItemBox.width, ItemBox.height);
                            if (boxRect.contains(new Point(Window.mouseX, Window.mouseY))){

                                if (inventory[boxX][boxY].itemType == holdingBox.itemType || inventory[boxX][boxY].itemType == 0){

                                    inventory[boxX][boxY].itemType = holdingBox.itemType;
                                    int itemsInTargetBox = inventory[boxX][boxY].itemsHeld;
                                    int itemsInHeldBox = holdingBox.itemsHeld;

                                    if (itemsInHeldBox + itemsInTargetBox > ItemBox.MAX_STACK_SIZE){
                                        inventory[boxX][boxY].itemsHeld = ItemBox.MAX_STACK_SIZE;
                                        holdingBox.itemsHeld = (itemsInHeldBox + itemsInTargetBox) - ItemBox.MAX_STACK_SIZE;
                                    } else {
                                        inventory[boxX][boxY].itemsHeld = itemsInHeldBox + itemsInTargetBox;
                                        holdingBox.itemsHeld = 0;
                                        holdingBox.itemType = 0;
                                    }

                                }

                            }
                        }catch (Exception e){}
                    }
                }
                
            }
        }
        
        if (holdingBlocks){
            
        }
        
        mouseWasDown = Window.mouseDown;
        
    }
    
    public void draw(Graphics g){
        try {
            g.setColor(Color.white);
            g.fillRect(inventory[selected-1][0].pixelX, inventory[selected-1][0].pixelY, ItemBox.width, ItemBox.height);
        } catch (IndexOutOfBoundsException e){
            // selected is 0 when moving block in inventory
        }
        if (showFull){
            for (int x = 0; x < inventory.length; x++){
                for (int y = 0; y < inventory[0].length; y++){
                    inventory[x][y].draw(g);
                }
            }
        } else {
            for (int i = 0; i < inventory.length; i++){
                inventory[i][0].draw(g);
            }
        }
        
        if (holdingBlocks){
            g.drawImage(Terrain.THUMBNAIL_IMAGES[holdingBox.itemType], Window.mouseX, Window.mouseY, null);
        }
        
    }
    
    public boolean addBlock(int _type){
        boolean canAdd = false;
      
        for (int boxY = 0; boxY < inventory[0].length; boxY++){
            for (int boxX = 0; boxX < inventory.length; boxX++){
                if (inventory[boxX][boxY].itemType == _type && inventory[boxX][boxY].itemsHeld < ItemBox.MAX_STACK_SIZE || inventory[boxX][boxY].itemType == 0){
                   canAdd = true;
                   inventory[boxX][boxY].itemType = _type;
                   inventory[boxX][boxY].itemsHeld++;
                   boxX = inventory.length + 1;
                   boxY = inventory[0].length + 1;
                }
            }
        }
        
        return canAdd;
    }
    
    protected class ItemBox {
        public static final int MAX_STACK_SIZE = 32;
        public static final int width = 30;
        public static final int height = 30;
        public static final int imageMargin = 3;
        
        public int itemsHeld = 0;
        int itemType;
        
        public int arrayX, arrayY;
        public int pixelX, pixelY;
        public int xGap = 5, yGap = 5;
        public int xOffset = 10, yOffset = 10;
        
        public ItemBox(int _x, int _y){
            arrayX = _x;
            arrayY = _y;
            pixelX = _x * (width+xGap) + xOffset;
            pixelY = _y * (height+yGap) + yOffset;
        }
        
        public boolean addItem(int type){
            boolean canAdd = true;
            
            if (type != itemType && itemType != 0){
                canAdd = false;
            }
            
            if (canAdd){
                itemsHeld++;
                itemType = type;
            }
            
            return canAdd;
        }
        
        public void update(){
            
        }
        
        public void draw(Graphics g){
            g.drawImage(BOX_IMAGE, pixelX, pixelY, null);
            
            g.drawImage(Terrain.THUMBNAIL_IMAGES[itemType], pixelX+ItemBox.imageMargin, pixelY+ItemBox.imageMargin, null);
            
            if (itemType != 0){
                g.setColor(Color.white);
                g.setFont(new Font(Font.DIALOG, Font.PLAIN, 10));
                g.drawString(itemsHeld + "", pixelX+2, pixelY+6);
            }
        }
        
    }
}
