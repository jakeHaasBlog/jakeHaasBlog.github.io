
package zombiedefense;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import sun.audio.AudioPlayer;
import sun.audio.AudioStream;

public class FileReader {
    
    public static BufferedImage getImage(String filepath, int width, int height){
        
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        try {
            image.getGraphics().drawImage(ImageIO.read(new File(filepath)).getScaledInstance(width, height, Image.SCALE_DEFAULT), 0, 0, null);
        } catch (Exception e){
            e.printStackTrace();
            System.exit(1);
        }
        return image;
        
    }
    
    public static void playAudio(String filepath){
        FileInputStream audioFile;
        try {
            audioFile = new FileInputStream(new File(filepath));
            AudioStream audioStream = new AudioStream(audioFile);
            AudioPlayer.player.start(audioStream);
            
        } catch (Exception e){
            e.printStackTrace();
            System.exit(1);
        }
    }
    
    
    private static SimpleAudioPlayer player = null;
    public static void placeBlockSound(){
        
        if (player == null){
            try {
                player = new SimpleAudioPlayer("placeBlock-cut.wav");
            } catch (UnsupportedAudioFileException ex) {
                Logger.getLogger(FileReader.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(FileReader.class.getName()).log(Level.SEVERE, null, ex);
            } catch (LineUnavailableException ex) {
                Logger.getLogger(FileReader.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        
        try {
            player.resetAudioStream();
        } catch (IOException ex) {
            Logger.getLogger(FileReader.class.getName()).log(Level.SEVERE, null, ex);
        } catch (LineUnavailableException ex) {
            Logger.getLogger(FileReader.class.getName()).log(Level.SEVERE, null, ex);
        } catch (UnsupportedAudioFileException ex) {
            Logger.getLogger(FileReader.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        player.play();
        
    }
    
}
