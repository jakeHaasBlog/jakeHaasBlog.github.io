
package zombiedefense;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

public class Character {
    
    public static float x;
    public static float y;
    public static float xAcceleration = 1;
    public static float g = -0.2f;
    public static float jumpSpeed = 7;
    public static float xSpeed = 0, ySpeed = 0;
    public static final float MAX_X_SPEED = 4, MAX_Y_SPEED = (Terrain.Block.HEIGHT/2);
    public static final int PIXELS_TALL = 36;
    public static final int PIXELS_WIDE = 22;
    public static BufferedImage spriteRight = FileReader.getImage("player-sprite-right.png", PIXELS_WIDE, PIXELS_TALL);
    public static BufferedImage spriteLeft = FileReader.getImage("player-sprite-left.png", PIXELS_WIDE, PIXELS_TALL);
    public static final int HEART_WIDTH = 20;
    public static final int HEART_HEIGHT = 20;
    public static final BufferedImage HEART = FileReader.getImage("heart.png", HEART_WIDTH, HEART_HEIGHT);
    public static final BufferedImage DEAD_HEART = FileReader.getImage("deadHeart.png", HEART_WIDTH, HEART_HEIGHT);
    public static final BufferedImage DAMAGE_FLASH = FileReader.getImage("damageFlash.png", ZombieDefense.window.getWidth(), ZombieDefense.window.getHeight());
    public static boolean showDamageFlash = false;
    public static long deathTimer = System.currentTimeMillis();
    
    public static int deathCounter = 0;
    
    public static int health = 10;
    public static final int MAX_HEALTH = 10;
    
    private static boolean hitGround = false;
    
    public static Inventory inventory = new Inventory();
    
    public static void init(){
        x = Terrain.SPAWN_X;
        y = Terrain.SPAWN_Y;
    }
    
    public static int getCameraOffsetX(){
        return (ZombieDefense.window.getWidth() / 2) - PIXELS_WIDE/2;
    }
    
    public static int getCameraOffsetY(){
        return (ZombieDefense.window.getHeight() / 2) - PIXELS_TALL/2;
    }
    
    private static boolean wasDead = false;
    public static void update(){
        
        if (health > 0){
            wasDead = false;
            changeInVelocity();
            limitSpeed();
            collisions();
            fallDamage();
            inventory.update();
            placeBlocks();
        } else {
            x = Terrain.SPAWN_X;
            y = Terrain.SPAWN_Y;
            
            if (!wasDead){
                deathCounter++;
                System.out.println("Number of Deaths: " + deathCounter);
            }
            
            if (System.currentTimeMillis() - deathTimer > 2000){
                health = MAX_HEALTH/2;
            }
            wasDead = true;
        }
        
    }
    
    public static void changeInVelocity(){
        ySpeed -= g;
        
        // w
        if (Window.keysDown[87]){
            try{
                boolean canJump = false;
                for (int blockX = (int)x; blockX < (int)x + PIXELS_WIDE + 1; blockX+= Terrain.Block.WIDTH){
                    if (Terrain.blocks[Terrain.getBlockAtX(blockX)][Terrain.getBlockAtY(y+PIXELS_TALL+(Terrain.Block.HEIGHT/2))].solid){
                        canJump = true;
                    }
                }
                if (Terrain.blocks[Terrain.getBlockAtX((int)x + PIXELS_WIDE -1)][Terrain.getBlockAtY(y+PIXELS_TALL+(Terrain.Block.HEIGHT/2))].solid){
                       
                    if (Terrain.getBlockAtY(y+PIXELS_TALL)*Terrain.Block.HEIGHT - y < 2){
                        canJump = true;
                    }
                        
                }
                if (canJump) ySpeed = -jumpSpeed;
            } catch (Exception e){}
        }
        // a
        if (Window.keysDown[65]){
            xSpeed -= xAcceleration;
        }
        // d
        else if (Window.keysDown[68]){
            xSpeed += xAcceleration;
        } else {
            if (xSpeed > 0){
                xSpeed -= 0.5;
            } else {
                xSpeed += 0.5;
            }
            if (-1 < xSpeed && xSpeed < 1) xSpeed = 0;
        }
    }
    
    public static void limitSpeed(){
        if (ySpeed > 0){
            if (Math.abs(ySpeed) > MAX_Y_SPEED) ySpeed = MAX_Y_SPEED;
        } else {
            if (Math.abs(ySpeed) > MAX_Y_SPEED) ySpeed = -MAX_Y_SPEED;
        }
        if (xSpeed > 0){
            if (Math.abs(xSpeed) > MAX_X_SPEED) xSpeed = MAX_X_SPEED;
        } else {
            if (Math.abs(xSpeed) > MAX_X_SPEED) xSpeed = -MAX_X_SPEED;
        }
    }
    
    public static void collisions(){
        float previousX = x, previousY = y;
        
        x += xSpeed;
        if (inBlock()){
            if (xSpeed > 0){
                y -= Terrain.Block.HEIGHT;
                if (inBlock()){
                    y = previousY;
                    x = previousX;
                }
            } else if (xSpeed < 0){
                y -= Terrain.Block.HEIGHT;
                if (inBlock()){
                    y = previousY;
                    x = previousX;
                }
            }
        }
        
        y += ySpeed;
        if (inBlock()){
            if (ySpeed > 0){
                y = Terrain.getBlockAtY(y)*Terrain.Block.HEIGHT;
                hitGround = true;
            } else {
                y = previousY;
                ySpeed = 0;
            }
        } else {
            hitGround = false;
        }
    }
    
    private static int beganFallingY;
    private static boolean wasFalling = false;
    private static final float HP_LOST_PER_PIXEL = 0.000015f;
    private static final int FLASH_LENGTH = 200;
    private static long flashTimer = System.currentTimeMillis() + FLASH_LENGTH;
    public static void fallDamage(){
        
        if (ySpeed > 0){
            if (!wasFalling){
                beganFallingY = (int)y;
            }
        }
        
        if (wasFalling){
            if (hitGround){
                float fallDist = y - beganFallingY;
                if ((int)(fallDist * fallDist * HP_LOST_PER_PIXEL)>0) {
                    damage((int)(fallDist * fallDist * HP_LOST_PER_PIXEL));
                }
            }
        }
        
        if (System.currentTimeMillis() - flashTimer < FLASH_LENGTH){
            showDamageFlash = true;
        } else {
            showDamageFlash = false;
        }
        
        if (ySpeed > 0){
            wasFalling = true;
        } else {
            wasFalling = false;
        }
        
        if (hitGround) beganFallingY = (int)y;
    }
    
    
    public static boolean inBlock(){
        
        boolean collide = false;
           
        Rectangle block;
        Rectangle characterBox = new Rectangle((int)x, (int)y, PIXELS_WIDE, PIXELS_TALL);

        for (int blockX = (int)x - 2*Terrain.Block.WIDTH; blockX < (int)x + PIXELS_WIDE + Terrain.Block.WIDTH*2; blockX+=Terrain.Block.WIDTH/2){
            for (int blockY = (int)y - 2*Terrain.Block.HEIGHT; blockY < (int)y + PIXELS_TALL + Terrain.Block.HEIGHT*2; blockY+=Terrain.Block.HEIGHT/2){
                try {
                    if (Terrain.blocks[Terrain.getBlockAtX(blockX)][Terrain.getBlockAtY(blockY)].solid){
                        block = new Rectangle(Terrain.getBlockAtX(blockX)*Terrain.Block.WIDTH, Terrain.getBlockAtY(blockY)*Terrain.Block.HEIGHT, Terrain.Block.WIDTH, Terrain.Block.HEIGHT);
                        if (characterBox.intersects(block)) collide = true;
                    }
                } catch (IndexOutOfBoundsException e){}
            }
        }
            
        
        return collide;
    }
    
    public static void placeBlocks(){
        try {
            if (Window.mouseDown){
                if (inventory.inventory[inventory.selected-1][0].itemsHeld > 0){
                    int placeType = inventory.inventory[inventory.selected-1][0].itemType;
                    int placeX = Terrain.getBlockAtX(Window.relitiveMouseX);
                    int placeY = Terrain.getBlockAtY(Window.relitiveMouseY);
                    if (Terrain.blocks[placeX][placeY].type == 0){
                        Terrain.Block newBlock = new Terrain.Block((short)placeType, placeX, placeY);
                        Terrain.blocks[placeX][placeY] = newBlock;
                        inventory.inventory[inventory.selected-1][0].itemsHeld--;
                        if (inventory.inventory[inventory.selected-1][0].itemsHeld <= 0) inventory.inventory[inventory.selected-1][0].itemType = 0;
                        FileReader.placeBlockSound();
                    }
                }
            } else if (Window.rightMouseDown){
                Terrain.blocks[Terrain.getBlockAtX(Window.relitiveMouseX)][Terrain.getBlockAtY(Window.relitiveMouseY)].breakBlock();
            }
        } catch (Exception e){}
    }
    
    public static void drawHp(Graphics g){
        
        for (int i = 0; i < MAX_HEALTH; i++){
            g.drawImage(DEAD_HEART, ZombieDefense.window.getWidth() - (HEART_WIDTH * i) - 40, 10, null);
        } 
        if (health > 0){
            for (int i = 0; i < health; i++){
                g.drawImage(HEART, ZombieDefense.window.getWidth() - (HEART_WIDTH * i) - 40, 10, null);
            } 
        }
        
    }
    
    public static float getRelitiveX(float _x){
        return _x - x + getCameraOffsetX();
    }
    public static float getRelitiveY(float _y){
        return _y - y + getCameraOffsetY();
    }
    
    public static void draw(Graphics g){
        if (health > 0){
            if (xSpeed > 0) g.drawImage(spriteRight, (int)getRelitiveX(x), (int)getRelitiveY(y), null);
            else g.drawImage(spriteLeft, (int)getRelitiveX(x), (int)getRelitiveY(y), null);

            if (showDamageFlash) g.drawImage(DAMAGE_FLASH, 0, 0, null);

            inventory.draw(g);
            drawHp(g);
        } else {
            g.drawImage(DAMAGE_FLASH, 0, 0, null);
        }
    }
    
    private static long dammageTimer = System.currentTimeMillis();
    private static int invinsibilityPeriod = 500;
    public static void damage(float damage){
        if (damage > 0){
            if (System.currentTimeMillis() - dammageTimer > invinsibilityPeriod){
                health -= (int)damage;
                dammageTimer = System.currentTimeMillis();
                flashTimer = System.currentTimeMillis();
                deathTimer = System.currentTimeMillis();
            }
        }
    }
    
}
