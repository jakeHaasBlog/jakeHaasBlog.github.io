
package zombiedefense;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class Terrain {
    
    public static final int MAP_WIDTH = 8400;
    public static final int MAP_HEIGHT = 2400;
    //public static final int MAP_WIDTH = 1000;
    //public static final int MAP_HEIGHT = 200;
    
    public static int SPAWN_X;
    public static int SPAWN_Y;
    
    private static final double HILL_EXTREMES = 20;
    
    protected static Block[][] blocks = new Block[MAP_WIDTH][MAP_HEIGHT];
    
    protected static final String BLOCK_NAMES[] = {
        "Air",
        "dirtBlock.png",
        "grassBlock.png",
        "wood.png",
        "leavesBlock.png",
        "stoneBlock.png"
    };
    
    protected static final BufferedImage BLOCK_IMAGES[] = {
        null,                                                           // air        0
        FileReader.getImage(BLOCK_NAMES[1], Block.WIDTH, Block.HEIGHT), // dirt       1
        FileReader.getImage(BLOCK_NAMES[2], Block.WIDTH, Block.HEIGHT), // grass      2
        FileReader.getImage(BLOCK_NAMES[3], Block.WIDTH, Block.HEIGHT), // wood       3
        FileReader.getImage(BLOCK_NAMES[4], Block.WIDTH, Block.HEIGHT), // leaves     4
        FileReader.getImage(BLOCK_NAMES[5], Block.WIDTH, Block.HEIGHT), // stone      5
    };
    
    protected static final BufferedImage THUMBNAIL_IMAGES[] = {
        null,
        FileReader.getImage(BLOCK_NAMES[1], Inventory.ItemBox.width - Inventory.ItemBox.imageMargin * 2, Inventory.ItemBox.height - Inventory.ItemBox.imageMargin * 2),
        FileReader.getImage(BLOCK_NAMES[2], Inventory.ItemBox.width - Inventory.ItemBox.imageMargin * 2, Inventory.ItemBox.height - Inventory.ItemBox.imageMargin * 2), 
        FileReader.getImage(BLOCK_NAMES[3], Inventory.ItemBox.width - Inventory.ItemBox.imageMargin * 2, Inventory.ItemBox.height - Inventory.ItemBox.imageMargin * 2), 
        FileReader.getImage(BLOCK_NAMES[4], Inventory.ItemBox.width - Inventory.ItemBox.imageMargin * 2, Inventory.ItemBox.height - Inventory.ItemBox.imageMargin * 2), 
        FileReader.getImage(BLOCK_NAMES[5], Inventory.ItemBox.width - Inventory.ItemBox.imageMargin * 2, Inventory.ItemBox.height - Inventory.ItemBox.imageMargin * 2), 
    };
    
    protected static final BufferedImage BROKEN_BLOCK_IMAGES[] = {
        null,
        FileReader.getImage(BLOCK_NAMES[1], BrokenBlock.WIDTH, BrokenBlock.HEIGHT),
        FileReader.getImage(BLOCK_NAMES[2], BrokenBlock.WIDTH, BrokenBlock.HEIGHT),
        FileReader.getImage(BLOCK_NAMES[3], BrokenBlock.WIDTH, BrokenBlock.HEIGHT),
        FileReader.getImage(BLOCK_NAMES[4], BrokenBlock.WIDTH, BrokenBlock.HEIGHT),
        FileReader.getImage(BLOCK_NAMES[5], BrokenBlock.WIDTH, BrokenBlock.HEIGHT),
    };
    
    public static BufferedImage loadingScreen = FileReader.getImage("loadingBackground.png", ZombieDefense.window.getWidth(), ZombieDefense.window.getHeight());

    public static ArrayList<BrokenBlock> brokenBlocks = new ArrayList<BrokenBlock>();
    
    public static void generate(Graphics g){
        
        g.drawImage(loadingScreen, 0, 0, null);
        g.setColor(Color.white);
        try {
            g.setFont(new Font("TimesRoman", Font.BOLD, 20));
        } catch (Exception e){
            g.setFont(new Font(Font.DIALOG, Font.BOLD, 20));
        }
        ZombieDefense.window.repaint();
        
        generateDirt(g);
        generateGrass(g);
        generateStone(g);
        generateTrees(g);
        
        SPAWN_X = (MAP_WIDTH/2) * Block.WIDTH;
        SPAWN_Y = (int)hillAlgorithm(SPAWN_X);
        
        System.out.println(MAP_WIDTH*MAP_HEIGHT + " blocks generated");
    }
    
    private static int frames = 0;
    public static void loadingScreen(String loadingText, Graphics g){
        if (frames % 20 == 0){
            g.drawImage(loadingScreen, 0, 0, null);
            g.setColor(Color.white);
            g.drawString(loadingText, 400, 500);
        }
        frames++;
    }
    
    public static void generateDirt(Graphics g){
        int percentage;
        for (int x = 0; x < MAP_WIDTH; x++){
            for (int y = 0; y < MAP_HEIGHT; y++){
                if (y > hillAlgorithm(x)){
                    blocks[x][y] = new Block((short)1, x, y);
                } else {
                    blocks[x][y] = new Block((short)0, x, y);
                }
            }
            percentage = (int)((x/(float)MAP_WIDTH)*100);
            if (x % 20 == 0) loadingScreen("Generating Dirt - " + percentage + "%", g);
        }
    }
    
    public static double k1 = (Math.random()*0.02);
    public static double d1 = (Math.random()*100);
    public static double k2 = (Math.random()*0.02)+0.03;
    public static double d2 = (Math.random()*1000);
    public static double k3 = (Math.random()*0.02)+0.03;
    public static double d3 = (Math.random()*1000);
    public static double k4 = (Math.random()*0.05)+0.08;
    public static double d4 = (Math.random()*1000);
    private static double hillAlgorithm(int x){
        double y;
            y = Math.sin((x + d1) * k1) * HILL_EXTREMES/3;
            y += Math.sin((x + d2) * k2) * HILL_EXTREMES/2;
            y -= Math.sin((x + d3) * k3) * HILL_EXTREMES/3;
            y += Math.sin((x + d4) * k4) * HILL_EXTREMES/5;
        return y + HILL_EXTREMES * 2;
    }
    
    public static void generateGrass(Graphics g){
        int percentage;
        for (int x = 0; x < blocks.length; x++){
            for (int y = 0; y < blocks[0].length; y++){
                try {
                    if (blocks[x][y].type == 1){
                        for (int x2 = -1; x2 <= 1; x2++){
                            for (int y2 = -1; y2 <= 1; y2++){
                                if (blocks[x2+x][y2+y].type == 0){
                                    blocks[x][y].type = 2;
                                }
                            }
                        }
                    }
                } catch (Exception e){}
            }
            percentage = (int)((x/(float)MAP_WIDTH)*100);
            if (x % 20 == 0) loadingScreen("Generating Grass - " + percentage + "%", g);
        }
    }
    
    public static void generateStone(Graphics g){
        for (int i = 0; i < Terrain.blocks.length; i++){
            makeStonePatch((int)(Math.random() * Terrain.blocks.length), (int)(Math.random() * Terrain.blocks[0].length));
        }
    }
    
    public static void makeStonePatch(int _x, int _y){
        int x;
        int y;
        for (int i = 0; i < 10; i++){
            x = _x;
            y = _y;
            for (int path = 0; path < (int)(Math.random()*8); path++){
                try {
                    if (Terrain.blocks[x][y].type == 1) Terrain.blocks[x][y] = new Terrain.Block((short)5, x, y);
                    x += (int)(Math.random()*2)-1;
                    y += (int)(Math.random()*2)-1;
                } catch (Exception e){}
            }
        }
    }
    
    public static void generateTrees(Graphics g){
        for (int x = 0; x < MAP_WIDTH; x++){
            for (int y = 0; y < MAP_HEIGHT / 5; y++){
                if (Terrain.blocks[x][y].type == 2){
                    if ((int)(Math.random()*20) == 0){
                        generateTree(x, y);
                    }
                }
            }
        }
    }
    
    public static void generateTree(int x, int y){
        int trunkHeight = (int)(Math.random() * 20) + 5;
        int currentX = x;
        int currentY = y;
        int moveByX;
        int moveByY;
        for (int i = 0; i < trunkHeight; i++){
            switch ((int)(Math.random()*10)){
                case 0:
                    moveByX = 1;
                    moveByY = 0;
                    break;
                case 1:
                    moveByX = -1;
                    moveByY = 0;
                    break;
                case 2:
                    moveByX = 1;
                    moveByY = -1;
                    break;
                case 3:
                    moveByX = -1;
                    moveByY = -1;
                    break;
                default:
                    moveByX = 0;
                    moveByY = -1;
                    break;
            }
            
            currentX += moveByX;
            currentY += moveByY;
            
            try {
                if (!Terrain.blocks[currentX][currentY].solid){
                    Terrain.blocks[currentX][currentY] = new Terrain.Block((short)3, currentX, currentY);
                }
            } catch (ArrayIndexOutOfBoundsException e){}
            
        }
        
        makeLeaves(currentX, currentY, trunkHeight / 3);
        
    }
    
    public static void makeLeaves(int x, int y, int length){
        float currentX;
        float currentY;
        float direction;
        for (int i = 0; i < length * 10; i++){
            currentX = x;
            currentY = y;
            direction = (2*3.14159f) * (float)((float)i / ((float)length*10f));
            
            try {
                for (int j = 0; j < length; j++){
                    if (!Terrain.blocks[(int)currentX][(int)currentY].solid){
                        Terrain.blocks[(int)currentX][(int)currentY] = new Terrain.Block((short)4, (int)currentX, (int)currentY);
                    }
                    currentX += Math.cos(direction);
                    currentY += Math.sin(direction);
                }
            } catch (ArrayIndexOutOfBoundsException e){}
            
        }
    }
    
    public static int getBlockAtX(float x){
        return (int)((x / (MAP_WIDTH*Block.WIDTH)) * MAP_WIDTH);
    }
    
    public static int getBlockAtY(float y){
        return (int)((y / (MAP_HEIGHT*Block.HEIGHT)) * MAP_HEIGHT);
    }
    
    public static void draw(Graphics g){
        int startingBlockX = getBlockAtX(Character.x - Character.getCameraOffsetX());
        int startingBlockY = getBlockAtY(Character.y - Character.getCameraOffsetY());
        int blocksAcrossScreenX = ZombieDefense.window.getWidth() / Block.WIDTH;
        int blocksAcrossScreenY = ZombieDefense.window.getHeight() / Block.HEIGHT;
        for (int x = startingBlockX; x < startingBlockX + blocksAcrossScreenX + 2; x++){
            for (int y = startingBlockY; y < startingBlockY + blocksAcrossScreenY + 1; y++){
                try {
                    if (blocks[x][y].type != 0) blocks[x][y].draw(g);
                } catch (Exception e){}
            }
        }
        
        for (int i = 0; i < brokenBlocks.size(); i++){
            brokenBlocks.get(i).draw(g);
        }
    }
    
    public static void update(){
        for (int i = 0; i < brokenBlocks.size(); i++){
            brokenBlocks.get(i).update();
            while (brokenBlocks.size() > 100){
                brokenBlocks.remove(0);
            }
        }
    }
    
    public static class Block{
        public static final short WIDTH = 13; //13
        public static final short HEIGHT = 13;
        public final int x, y; // position in array
        public boolean solid = true;
        
        public short type; 
        
        float hp;
        float maxHp;
        
        public Block(short _type, int _x, int _y){
            type = _type;
            x = _x;
            y = _y;
            hp = type * type;
            maxHp = type * type;
            if (type == 0) solid = false;
            if (type == 3) solid = false;
            if (type == 4) solid = false;
        }
        
        public void draw(Graphics g){
            if (hp < maxHp) hp += 0.01;
            g.drawImage(BLOCK_IMAGES[type], (int)Character.getRelitiveX(x*Block.WIDTH), (int)Character.getRelitiveY(y*Block.HEIGHT), null);
        }
        
        public void breakBlock(){
            if (type != 0){
                brokenBlocks.add(new BrokenBlock(x*WIDTH + (int)(Math.random()*WIDTH) - BrokenBlock.WIDTH, y*HEIGHT, type));
                type = 0;
                solid = false;
            }
        }
        
        public void damage(float damage){
            hp -= damage;
            if (hp < 0){
                breakBlock();
            }
        }
    }
    
    
    public static class BrokenBlock {
        int x, y;
        int type;
        public static final int WIDTH = 10;
        public static final int HEIGHT = 10;
        
        public BrokenBlock(int _x, int _y, int _type){
            x = _x;
            y = _y;
            type = _type;
        }
        
        public void update(){
            
            int previousY = y;
            
            y += 1;
            try {
                if (Terrain.blocks[Terrain.getBlockAtX(x)][Terrain.getBlockAtY(y+BrokenBlock.HEIGHT)].solid){
                    y = previousY;
                }
            } catch (Exception e){}
            
            Rectangle characterBox = new Rectangle((int)Character.x, (int)Character.y, Character.PIXELS_WIDE, Character.PIXELS_TALL);
            Rectangle blockBox = new Rectangle(x, y, BrokenBlock.WIDTH, BrokenBlock.HEIGHT);
            
            if (characterBox.intersects(blockBox)){
                if (Character.inventory.addBlock(type)){
                    brokenBlocks.remove(this);
                }
            }
            
        }
        
        public void draw(Graphics g){
            g.drawImage(BROKEN_BLOCK_IMAGES[type], (int)Character.getRelitiveX(x), (int)Character.getRelitiveY(y), null);
        }
    }
}
