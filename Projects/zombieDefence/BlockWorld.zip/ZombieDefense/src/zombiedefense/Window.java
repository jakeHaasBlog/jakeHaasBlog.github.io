
package zombiedefense;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class Window extends JFrame {
    
    public static boolean keysDown[] = new boolean[222];
    public static boolean mouseDown = false;
    public static boolean rightMouseDown = false;
    public static int mouseX = 0;
    public static int mouseY = 0;
    public static int relitiveMouseX = 0;
    public static int relitiveMouseY = 0;
    private Panel rootPanel;
    
    public Window() {
        setSize(1080, 720);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(true);
        setLayout(null);
        
        setCursor( this.getToolkit().createCustomCursor(new BufferedImage( 1, 1, BufferedImage.TYPE_INT_ARGB ),new Point(), null ));
        
        addKeyListener(new KeyListener(){
            @Override
            public void keyPressed(KeyEvent e) {
                keysDown[e.getKeyCode()] = true;
            }

            @Override
            public void keyReleased(KeyEvent e) {
                keysDown[e.getKeyCode()] = false;
            }
            
            @Override
            public void keyTyped(KeyEvent e) {}
        });
        
        addMouseListener(new MouseListener(){
            @Override
            public void mousePressed(MouseEvent me) {
                if (SwingUtilities.isRightMouseButton(me)) rightMouseDown = true;
                if (SwingUtilities.isLeftMouseButton(me)) mouseDown = true;
            }
            @Override
            public void mouseReleased(MouseEvent me) {
                if (SwingUtilities.isRightMouseButton(me)) rightMouseDown = false;
                if (SwingUtilities.isLeftMouseButton(me)) mouseDown = false;
            }
            public void mouseClicked(MouseEvent me) {}
            public void mouseEntered(MouseEvent me) {}
            public void mouseExited(MouseEvent me) {}
        });
        
        rootPanel = new Panel(getWidth(), getHeight());
        getRootPane().addComponentListener(new ComponentAdapter() {
            public void componentResized(ComponentEvent e) {
                rootPanel.setSize(getWidth(), getHeight());
            }
        });
        
        addMouseMotionListener(new MouseMotionListener(){
            @Override
            public void mouseDragged(MouseEvent me) {
                mouseX = me.getX() - 5;
                mouseY = me.getY() - 29;
                relitiveMouseX = mouseX + (int)Character.x - Character.getCameraOffsetX();
                relitiveMouseY = mouseY + (int)Character.y - Character.getCameraOffsetY();
            }

            @Override
            public void mouseMoved(MouseEvent me) {
                mouseX = me.getX() - 5;
                mouseY = me.getY() - 29;
                relitiveMouseX = mouseX + (int)Character.x - Character.getCameraOffsetX();
                relitiveMouseY = mouseY + (int)Character.y - Character.getCameraOffsetY();
            }
        });
        
        add(rootPanel);
        setIgnoreRepaint(true);
        setVisible(true);
    }
    
    class Panel extends JPanel {
        public Panel(int _width, int _height){
            setSize(_width, _height);
            setVisible(true);
        }
        
        @Override
        public void paintComponent(Graphics g){
            g.setColor(Color.black);
            g.fillRect(0, 0, getWidth(), getHeight());
            ZombieDefense.draw(g);
        }
    }
    
}
