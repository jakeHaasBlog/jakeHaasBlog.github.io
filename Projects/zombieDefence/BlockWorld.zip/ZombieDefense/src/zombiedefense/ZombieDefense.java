
package zombiedefense;

import java.awt.Graphics;
import java.awt.image.BufferedImage;


public class ZombieDefense {
    
    public static Window window = new Window();
    public static final int CURSOR_WIDTH = 20;
    public static final int CURSOR_HEIGHT = 20;
    public static BufferedImage cursor = FileReader.getImage("cursor.png", CURSOR_WIDTH, CURSOR_HEIGHT);
    
    public static void main(String[] args){
        Zombies.init();
        initialize();
        //DiggingZombie z = new DiggingZombie(10, Character.x, Character.y+200);
        //Zombie g = new Zombie(10, Character.x+60, Character.y+200);
        mainloop();
    }
    
    public static void initialize(){
        Terrain.generate(window.getContentPane().getGraphics());
        Character.init();
    }
    
    private static final int FPS = 60;
    public static void mainloop(){
        
        while (true) {
            tick();
            update();
            window.repaint();
        }
    }
    
    // holds the start time in milliseconds of this frame
    private static long startTime = System.nanoTime();
    static double fpsArray[] = new double[200];
    static long frame = 0;

    // limits the frame rate
    public static void tick() {
        frame++;
        
        double nanoBetween = ((double)System.nanoTime() - (double)startTime);
        double secBetween = nanoBetween / 1000000000d;
        double fps = (double) (1d / secBetween);
        
        fpsArray[(int)(frame % (long)(fpsArray.length))] = fps;

        if (frame % (FPS/10) == 0) {
            window.setTitle(String.format("FPS: %.2f", getFps()));
        }
        
        //startTime = System.nanoTime();
        
        if (secBetween < (1.0d / (double)FPS)){
            try {
                Thread.sleep((long)(((1d/(double)FPS) - secBetween)*1000));
            } catch (Exception e) {}
        }
        
        startTime = System.nanoTime();
    }
    
    public static double getFps() {
        double total = 0;
        for (double x : fpsArray) {
            total += x;
        }
        return total / (double)(fpsArray.length);
    }
    
    public static void update(){
        Character.update();
        Terrain.update();
        Zombies.update();
    }
   
    public static void draw(Graphics g){
        Terrain.draw(g);
        Character.draw(g);
        g.drawImage(cursor, Window.mouseX, Window.mouseY, null);
        Zombies.draw(g);
    }
    
}