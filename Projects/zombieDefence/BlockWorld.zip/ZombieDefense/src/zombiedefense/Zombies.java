
package zombiedefense;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import static zombiedefense.Zombies.getChunkYAtY;
import static zombiedefense.Zombies.zombieChunks;

public class Zombies {
    public static ZombieChunk[][] zombieChunks;
    private static int loadNumberOfChunks = 20;
            
    public static void init(){
        int chunksWide = (int)((float)(Terrain.MAP_WIDTH * Terrain.Block.WIDTH) / ZombieChunk.WIDTH);
        int chunksHigh = (int)((float)(Terrain.MAP_HEIGHT * Terrain.Block.HEIGHT) / ZombieChunk.HEIGHT);
        zombieChunks = new ZombieChunk[chunksWide][chunksHigh];
        
        for (int x = 0; x < zombieChunks.length; x++){
            for (int y = 0; y < zombieChunks[0].length; y++){
                zombieChunks[x][y] = new ZombieChunk();
            }
        }
    }
    
    public static int getChunkXAtX(int x){
        return (int)(((float)x / (float)((float)Terrain.MAP_WIDTH*Terrain.Block.WIDTH))*(float)zombieChunks.length);
    }
    public static int getChunkYAtY(int y){
        return (int)(((float)y / (float)((float)Terrain.MAP_HEIGHT*Terrain.Block.HEIGHT))*(float)zombieChunks[0].length);
    }
    
    public static void update(){
        
        for (int x = -loadNumberOfChunks; x <= loadNumberOfChunks; x++){
            for (int y = 0; y < zombieChunks[0].length; y++){
                try {
                    zombieChunks[getChunkXAtX((int)Character.x)+x][getChunkYAtY((int)Character.y)+y].update();
                } catch(Exception e){}
            }
        }
        
    }
    
    public static void draw(Graphics g){
        int chunkX;
        int chunkY;
        for (int x = -loadNumberOfChunks; x <= loadNumberOfChunks; x++){
            for (int y = 0; y < zombieChunks[0].length; y++){
                try {
                    
                    chunkX = (getChunkXAtX((int)Character.x)+x);
                    chunkY = (getChunkYAtY((int)Character.y)+y);
                    zombieChunks[chunkX][chunkY].draw(g);
                    
                } catch (Exception e){}
            }
        }
    }
}

class ZombieChunk {
    public static final int WIDTH = initChunkWidth();
    public static final int HEIGHT = initChunkHeight();
    public ArrayList<EnemyInterface> zombies = new ArrayList<>();
    
    private static int initChunkWidth(){
        float width = Terrain.Block.WIDTH * 10;
        
        while ((Terrain.MAP_WIDTH*Terrain.Block.WIDTH / width) - Math.round(Terrain.MAP_WIDTH*Terrain.Block.WIDTH / width) != 0){
            width += Terrain.Block.WIDTH;
        }
        System.out.println("Zombie chunk width: "+width);
        return (int)width;
    }
    private static int initChunkHeight(){
        float height = Terrain.Block.HEIGHT * 10;
        
        while ((Terrain.MAP_HEIGHT*Terrain.Block.HEIGHT / height) - Math.round(Terrain.MAP_HEIGHT*Terrain.Block.HEIGHT / height) != 0){
            height += Terrain.Block.HEIGHT;
        }
        
        System.out.println("Zombie chunk height: "+height);
        return (int)height;
    }
    
    public void update(){
        for (EnemyInterface enemy: zombies){
            enemy.update();
        }
    }
    
    public void draw(Graphics g){
        for (EnemyInterface enemy: zombies){
            enemy.draw(g);
        }
    }
}

interface EnemyInterface {
    
    public void move();
    
    public void update();
    
    public void attack();
    
    public boolean collided();
    
    public void draw(Graphics g);
}

abstract class AbstractEnemy implements EnemyInterface {
    public float x;
    public float y;
    public int health;
    public float xSpeed;
    public float ySpeed;
    public float xAcceleration = 0.1f;
    public float yAcceleration = 1;
    public static final float MAX_X_SPEED = 3;
    public static final float MAX_Y_SPEED = 3;
    public static final int WIDTH = Character.PIXELS_WIDE;
    public static final int HEIGHT = Character.PIXELS_TALL;
    public int currentChunkX;
    public int currentChunkY;
    public int damage = 1;
    
    protected static BufferedImage zombieImage  = FileReader.getImage("rabbit-zombie.jpg", WIDTH, HEIGHT);

    public AbstractEnemy(int hp, float _x, float _y){
        currentChunkX = Zombies.getChunkXAtX((int)_x);
        currentChunkY = getChunkYAtY((int)_y);
        x = _x;
        y = _y;
        zombieChunks[currentChunkX][currentChunkY].zombies.add(this);
    }

    @Override
    public boolean collided(){
        boolean inBlock = false;
        
        Rectangle enemyBox = new Rectangle((int)x, (int)y, WIDTH, HEIGHT);
        Rectangle terrainBox;
        
        int blocksTall = (int)Math.ceil(HEIGHT/Terrain.Block.HEIGHT);
        int blocksWide = (int)Math.ceil(WIDTH/Terrain.Block.WIDTH);
        for (int blockX = Terrain.getBlockAtX(x) - 1; blockX <= Terrain.getBlockAtX(x) + blocksWide + 1; blockX++){
            for (int blockY = Terrain.getBlockAtY(y) - 1; blockY <= Terrain.getBlockAtY(y) + blocksTall + 1; blockY++){
                
                try {
                    if (Terrain.blocks[blockX][blockY].solid){
                        terrainBox = new Rectangle(blockX*Terrain.Block.WIDTH, blockY*Terrain.Block.HEIGHT, Terrain.Block.WIDTH, Terrain.Block.HEIGHT);
                        if (enemyBox.intersects(terrainBox)) inBlock = true;
                    }
                } catch (IndexOutOfBoundsException e){}
            }
        }
        
        return inBlock;
    }
    
    boolean moveRight;
    @Override
    
    public void move(){
        
        if (x > Character.x) moveRight = false;
        else moveRight = true;
        
        if (moveRight) xSpeed += xAcceleration;
        else xSpeed -= xAcceleration;
        
        if (xSpeed > Character.MAX_X_SPEED) xSpeed = Character.MAX_X_SPEED;
        if (xSpeed < -Character.MAX_X_SPEED) xSpeed = -Character.MAX_X_SPEED;
        
        ySpeed += -Character.g;
        if (ySpeed > Character.MAX_Y_SPEED) ySpeed = Character.MAX_Y_SPEED;
        if (ySpeed < -Character.MAX_Y_SPEED) ySpeed = -Character.MAX_Y_SPEED;
        
        float previousX = x;
        float previousY = y;
        
        boolean canMoveX = true;
        
        x += xSpeed;
        if (collided()){
            y -= Terrain.Block.HEIGHT;
            if (collided()){
                y = previousY;
                x = previousX;
                canMoveX = false;
            } else {
                previousY = y;
                canMoveX = true;
            }
        }
        
        y += ySpeed;
        if (collided()){
            y = previousY;
            if (!canMoveX) jump();
        }
    }
    
    public void jump(){
        ySpeed = -Character.MAX_Y_SPEED;
    }
    
    @Override
    public void attack(){
        Rectangle hitBox = new Rectangle((int)x, (int)y, WIDTH, HEIGHT);
        Rectangle playerBox = new Rectangle((int)Character.x, (int)Character.y, Character.PIXELS_WIDE, Character.PIXELS_TALL);
        
        if (hitBox.intersects(playerBox)){
            Character.damage(damage);
        }
    }

    @Override
    public void update(){
        
        move();
        attack();
        
        setChunk();
    }
    
    public void setChunk(){
        // puts zombie in proper chunk, removes it from previous chunk
        if (currentChunkX != Zombies.getChunkXAtX((int)x) || currentChunkY != Zombies.getChunkYAtY((int)y)){
            zombieChunks[currentChunkX][currentChunkY].zombies.remove(this);
            
            currentChunkX = Zombies.getChunkXAtX((int)x);
            currentChunkY = Zombies.getChunkYAtY((int)y);
            zombieChunks[currentChunkX][currentChunkY].zombies.add(this);
        }
    }
    
    @Override
    public void draw(Graphics g){
        g.drawImage(zombieImage, (int)Character.getRelitiveX(x), (int)Character.getRelitiveY(y), null);
    }
}


class Zombie extends AbstractEnemy {
    
    public Zombie(int _hp, float _x, float _y){
        super(_hp, _x, _y);
    }
    
}

class DiggingZombie extends AbstractEnemy {
    
    public float terrainDamage = 0.1f;
    
    public DiggingZombie(int _hp, float _x, float _y){
        super(_hp, _x, _y);
    }
    
    @Override
    public void attack(){
        // hurts player when touching them
        super.attack();
        
        // digs a tunnel towards player one block at a time
        int targetX = 0;
        int targetY = 0;
        
        int startX;
        int startY;
        int endX;
        int endY;
        
        if (x < Character.x){
            startX = Terrain.getBlockAtX(x);
            endX = Terrain.getBlockAtX(x + WIDTH) + 1;
        } else {
            startX = Terrain.getBlockAtX(x) - 1;
            endX = Terrain.getBlockAtX(x);
        }
        
        if (y < Character.y){
            startY = Terrain.getBlockAtY(y)-2;
            endY = Terrain.getBlockAtY(y + HEIGHT + Terrain.Block.HEIGHT);
        } else {
            startY = Terrain.getBlockAtY(y) - 2;
            endY = Terrain.getBlockAtY(y + HEIGHT - Terrain.Block.HEIGHT);
        }
        
        for (int blockX = startX; blockX <= endX; blockX++){
            for (int blockY = startY; blockY <= endY; blockY++){
                if (Terrain.blocks[blockX][blockY].solid){
                    targetX = blockX;
                    targetY = blockY;
                }
            }
        }
        
        Terrain.blocks[targetX][targetY].damage(terrainDamage);
        
    }
    
    public void jump(){
        
    }
    
    public void update(){
        super.move();
        super.attack();
        super.setChunk();
        attack();
    }
    
}
