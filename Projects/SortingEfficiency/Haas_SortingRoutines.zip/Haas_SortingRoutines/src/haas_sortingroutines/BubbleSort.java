
package haas_sortingroutines;

import static haas_sortingroutines.SortingForm.display;

public class BubbleSort {
    
    public static void sort(int[] numbers, boolean reversed){
        
        // holds original numbers
        int[] orig = numbers.clone();
        
        // holds if the array is sorted yet
        boolean notSorted; 
        // placeholder for value when switching
        int placeholder;
        // holds when the sort started running
        double startTime = System.nanoTime();
        // holds how many times a loop was executed
        int numberOfLoops = 0;
        
        // holds where the numbers are sorted up to (puts highest values in order first)
        int sortedTo = numbers.length - 1;
       
        if (!reversed){
            do {
                notSorted = false;
                // for all values in array, if they are out of order switch them
                for (int i = 0; i < sortedTo; i++){
                    if (numbers[i] > numbers[i+1]){
                        // if the numbers are out of order switch them
                        placeholder = numbers[i];
                        numbers[i] = numbers[i+1];
                        numbers[i+1] = placeholder;
                        notSorted = true;
                    }
                    // increase the number of loops
                    numberOfLoops++;
                }
                sortedTo--;

            } while (notSorted);
        } else {
            do {
                notSorted = false;
                // for all values in array, if they are out of order switch them
                for (int i = 0; i < sortedTo; i++){
                    if (numbers[i] < numbers[i+1]){
                        // if the numbers are out of order switch them
                        placeholder = numbers[i];
                        numbers[i] = numbers[i+1];
                        numbers[i+1] = placeholder;
                        // because fdddddr54
                        notSorted = true;
                    }
                    // increase the number of loops
                    numberOfLoops++;
                }
                sortedTo--;

            } while (notSorted);
        }
        
        // calculate number of milliseconds spent sorting
        double totalSortTime = (System.nanoTime() - startTime) / 1000000;
        
        // display info for this search
        display(orig, numbers, totalSortTime, numberOfLoops, "BubbleSort", reversed);
    }
    
}
