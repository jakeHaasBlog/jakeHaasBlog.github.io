
package haas_sortingroutines;

import static haas_sortingroutines.SortingForm.display;

public class MergeSort {
    
    // holds the number of loops neccesary to sort fully
    private static int mergeSortLoops;
    
    public static void sort(int[] numbers, boolean reversed){
        
        // holds the orignial numbers
        int[] orig = numbers.clone();
        
        // sets the number of loops to zero
        mergeSortLoops = 0;
        
        // hold when the sort began
        double startTime = System.nanoTime();

        // calls merge sort recursively(splits data over and over again until only arrays with one value are left
        // then sorts while putting them back together)
        splitData(numbers, numbers.length, reversed);
        
        // display info for this search
        display(orig, numbers, (System.nanoTime() - startTime) / 1000000, mergeSortLoops, "Merge Sort", reversed);
    }
    
    /** used by the merge sort algorithm, can also be called independently to sort stuff but won't display anything */
    private static void splitData(int[] numbers, int length, boolean reversed) {
        
        // increase the number of loops it took to sort this array
        mergeSortLoops++;
        
        // if the array length is already 0, stop
        if (length < 2) return;
        
        // holds half way through array
        int half = length / 2;
        
        // declare arrays to hold split halves of array
        int[] leftArray = new int[half];
        int[] rightArray = new int[length - half];

        // put left half of array into new leftArray
        for (int i = 0; i < half; i++) {
            leftArray[i] = numbers[i];
        }
        
        // put right half of array into new rightArray
        for (int i = half; i < length; i++) {
            rightArray[i - half] = numbers[i];
        }
        
        // this method calls itself again to split up data even further
        splitData(leftArray, half, reversed);
        splitData(rightArray, length - half, reversed);

        // merges two haves in correct order
        if (!reversed) merge(numbers, leftArray, rightArray, half, length - half);
        else mergeReversed(numbers, leftArray, rightArray, half, length - half);
        
    }
    
    /** Used by the merge sort algorithm to take two arrays and put them together in ascending order */
    private static void merge(int[] fullArray, int[] leftArray, int[] rightArray, int leftLength, int rightLength) {
        
        // increase the number of loops it took to sort this array
        mergeSortLoops++;

        // temporary variables to hold how far into each array the sort is
        int indexLeft = 0, indexRight = 0, indexFull = 0;
        
        // while either array has not been fully looped through
        while (indexLeft < leftLength && indexRight < rightLength) {
            
            // if the left array at left index is less than the right array at right index
            if (leftArray[indexLeft] < rightArray[indexRight]) {
                // set full array at full array index to the left array at left array index
                fullArray[indexFull] = leftArray[indexLeft];
                // increase the full array index and left array index by one
                indexFull++;
                indexLeft++;
            }
            else {
                // if the right array at right index is less than the left array at left index
                fullArray[indexFull] = rightArray[indexRight];
                // increase the full array index and left array index by one
                indexFull++;
                indexRight++;
            }
        }
        
        // increase the number of loops it took to sort this array
        mergeSortLoops++;
        
        // If there are remaining items in the left array put them at end of full array(they should theoretically already be sorted)
        while (indexLeft < leftLength) {
            // fill the rest of the full array with rest of values
            fullArray[indexFull] = leftArray[indexLeft];
            // increase the full array index and left array index by one
            indexFull++;
            indexLeft++;
        }
        // increase the number of loops it took to sort this array
        mergeSortLoops++;
        
        // If there are remaining items in the right array put them at end of full array(they should theoretically already be sorted)
        while (indexRight < rightLength) {
            // fill the rest of the full array with rest of values
            fullArray[indexFull] = rightArray[indexRight];
            // increase the full array index and right array index by one
            indexRight++;
            indexFull++;
        }
        // increase the number of loops it took to sort this array
        mergeSortLoops++;
        
    }
    
    /** Used by the merge sort algorithm to take two arrays and put them together in descending order */
    private static void mergeReversed(int[] fullArray, int[] leftArray, int[] rightArray, int leftLength, int rightLength) {
        
        // increase the number of loops it took to sort this array
        mergeSortLoops++;

        // temporary variables to hold how far into each array the sort is
        int indexLeft = 0, indexRight = 0, indexFull = 0;
        
        // while either array has not been fully looped through
        while (indexLeft < leftLength && indexRight < rightLength) {
            
            // if the left array at left index is greater than the right array at right index
            if (leftArray[indexLeft] > rightArray[indexRight]) {
                // set full array at full array index to the left array at left array index
                fullArray[indexFull] = leftArray[indexLeft];
                // increase the full array index and left array index by one
                indexFull++;
                indexLeft++;
            }
            else {
                // if the right array at right index is less than the left array at left index
                fullArray[indexFull] = rightArray[indexRight];
                // increase the full array index and left array index by one
                indexFull++;
                indexRight++;
            }
        }
        
        // increase the number of loops it took to sort this array
        mergeSortLoops++;
        
        // If there are remaining items in the left array put them at end of full array(they should theoretically already be sorted)
        while (indexLeft < leftLength) {
            // fill the rest of the full array with rest of values
            fullArray[indexFull] = leftArray[indexLeft];
            // increase the full array index and left array index by one
            indexFull++;
            indexLeft++;
        }
        // increase the number of loops it took to sort this array
        mergeSortLoops++;
        
        // If there are remaining items in the right array put them at end of full array(they should theoretically already be sorted)
        while (indexRight < rightLength) {
            // fill the rest of the full array with rest of values
            fullArray[indexFull] = rightArray[indexRight];
            // increase the full array index and right array index by one
            indexRight++;
            indexFull++;
        }
        // increase the number of loops it took to sort this array
        mergeSortLoops++;
        
    }
    
}
