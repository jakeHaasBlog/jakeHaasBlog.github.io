
package haas_sortingroutines;

import static haas_sortingroutines.SortingForm.display;

public class QuickSort {
    
    private static int numberOfLoops;
    public static void sort(int[] numbers, boolean reversed){
        
        // sets the number of loops to zero
        numberOfLoops = 0;
        
        // holds the original unsorted numbers
        int[] orig = numbers.clone();
        
        // holds the time sort began in nanoseconds
        double startTime = System.nanoTime();
        
        // if the sort is not decending
        if (!reversed) quickSort(numbers, 0, numbers.length - 1);
        
        // if the sort is decending
        else quickSortReversed(numbers, 0, numbers.length - 1);
        
        // displays the sort data
        display(orig, numbers, (System.nanoTime() - startTime)/1000000, numberOfLoops, "Quicksort", reversed);
        
    }
    
    private static void quickSort(int[] numbers, int leftIndex, int rightIndex){
        
        // holds number for switching
        int placeHolder;
       
        // holds the current left and right indexes
        int leftI = leftIndex;
        int rightI = rightIndex;
        
        // holds the number in the middle of the two initial indexes
        int pivot = numbers[(rightIndex+leftIndex)/2];
        
        // indexes start on outside of the range of values then get closer together untill they hit eachother
        while (leftI <= rightI) {
            // sets leftI to the first number greater than the pivot number starting from the left to the right
            while (numbers[leftI] < pivot) {
                leftI++;
                numberOfLoops++;
            }
            // sets rightI to the first number less than the pivot number starting from the right to the left
            while (numbers[rightI] > pivot) {
                rightI--;
                numberOfLoops++;
            }
            // if the left index is still less than the right index
            if (leftI <= rightI) {
                // switches the numbers at the left and right indexes
                placeHolder = numbers[leftI];
                numbers[leftI] = numbers[rightI];
                numbers[rightI] = placeHolder;
                // moves the left and right indexes towards eachother
                leftI++;
                rightI--;
            }
            
        }
        // recursively calls this function on both halfs of new data set
        if (leftIndex < rightI) quickSort(numbers, leftIndex, rightI);
        if (leftI < rightIndex) quickSort(numbers, leftI, rightIndex);
    }
    
    
    private static void quickSortReversed (int[] numbers, int leftIndex, int rightIndex){
 
        // holds number for switching
        int placeHolder;
       
        // holds the current left and right indexes
        int leftI = leftIndex;
        int rightI = rightIndex;
        
        // holds the number in the middle of the two initial indexes
        int pivot = numbers[(rightIndex+leftIndex)/2];
        
        // indexes start on outside of the range of values then get closer together untill they hit eachother
        while (leftI <= rightI) {
            // sets leftI to the first number greater than the pivot number starting from the left to the right
            while (numbers[leftI] > pivot) {
                leftI++;
                numberOfLoops++;
            }
            // sets rightI to the first number less than the pivot number starting from the right to the left
            while (numbers[rightI] < pivot) {
                rightI--;
                numberOfLoops++;
            }
            // if the left index is still less than the right index
            if (leftI <= rightI) {
                // switches the numbers at the left and right indexes
                placeHolder = numbers[leftI];
                numbers[leftI] = numbers[rightI];
                numbers[rightI] = placeHolder;
                // moves the left and right indexes towards eachother
                leftI++;
                rightI--;
            }
        }
        // recursively calls this function on both halfs of new data set
        if (leftIndex < rightI) quickSortReversed(numbers, leftIndex, rightI);
        if (leftI < rightIndex) quickSortReversed(numbers, leftI, rightIndex);
        
    }
}