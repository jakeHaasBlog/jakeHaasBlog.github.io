
package haas_sortingroutines;

import static haas_sortingroutines.SortingForm.display;

public class InsertionSort {
    
    public static void sort(int[] numbers, boolean reversed){
        
        // hold the unsorted numbers
        int[] orig = numbers.clone();
        
        // hold the number of loops to fully sort the data
        int numberOfLoops = 0;
        
        // hold start time for this sort
        double startTime = System.nanoTime();
        
        // placeholder for number being sorted
        int placeHolder;
        
        if (!reversed){
            // for every number starting at one
            for (int currentIndex = 1; currentIndex < numbers.length; currentIndex++) { 

                // placeholder is the number at this index
                placeHolder = numbers[currentIndex];  

                // i begins at previous index
                int i = currentIndex-1;  
                // shifts the array to the right starting from the right and moving left until placeHolder is in the right order
                while ( (i >= 0) && (numbers[i] > placeHolder ) ) {  
                    // shifts number to the right in the array
                    numbers[i+1] = numbers[i];  
                    // i decreases by one
                    i--;  

                    // increases the number of loops by one
                    numberOfLoops++;
                }  
                // after shifting array to proper position, set number at begining of the shift to placeholder
                numbers[i+1] = placeHolder;  
            }  
        } else {
            // for every number starting at one
            for (int currentIndex = 1; currentIndex < numbers.length; currentIndex++) { 

                // placeholder is the number at this index
                placeHolder = numbers[currentIndex];  

                // i begins at previous index
                int i = currentIndex-1;  
                // shifts the array to the right starting from the right and moving left until placeHolder is in the right order
                while ( (i >= 0) && (numbers[i] < placeHolder ) ) {  
                    // shifts number to the right in the array
                    numbers[i+1] = numbers[i];  
                    // i decreases by one
                    i--;  

                    // increases the number of loops by one
                    numberOfLoops++;
                }  
                // after shifting array to proper position, set number at begining of the shift to placeholder
                numbers[i+1] = placeHolder;  
            }  
        }
    
        // set display strings according to this sort's information
        display(orig, numbers, (System.nanoTime() - startTime)/1000000, numberOfLoops, "Insertion Sort", reversed);
        
    }
    
}
