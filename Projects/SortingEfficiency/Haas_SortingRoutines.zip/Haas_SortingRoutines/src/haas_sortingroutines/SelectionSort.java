
package haas_sortingroutines;

import static haas_sortingroutines.SortingForm.display;

public class SelectionSort {
    
    public static void sort(int[] numbers, boolean reversed){
        // holds the original numbers being sorted
        int[] orig = numbers.clone();
        
        // holds the index of the last sorted number
        int sortedTo = 0;
        
        // holds a value temporarily for switching values
        int placeholder;
        
        // holds the number of loops to complete sort
        int numberOfLoops = 0;
        
        // holds the time in nanoseconds when the sort started
        double startTime = System.nanoTime();
        
        if (!reversed){
            int lowestIndex;
            // work through the whole array
            for (int n: numbers){
                lowestIndex = sortedTo;
                for (int i = sortedTo + 1; i < numbers.length; i++){
                    if (numbers[i] < numbers[lowestIndex]) lowestIndex = i;
                    numberOfLoops++;
                }

                // switch the lowest number index with end of sorted part
                placeholder = numbers[lowestIndex];
                numbers[lowestIndex] = numbers[sortedTo];
                numbers[sortedTo] = placeholder;

                // increse length of array that is sorted
                sortedTo++;
            }
        } else {
            int highestIndex;
            // work through the whole array
            for (int n: numbers){
                highestIndex = sortedTo;
                for (int i = sortedTo + 1; i < numbers.length; i++){
                    if (numbers[i] > numbers[highestIndex]) highestIndex = i;
                    numberOfLoops++;
                }

                // switch the lowest number index with end of sorted part
                placeholder = numbers[highestIndex];
                numbers[highestIndex] = numbers[sortedTo];
                numbers[sortedTo] = placeholder;

                // increse length of array that is sorted
                sortedTo++;
            }
        }
        
        // display info for this search
        display(orig, numbers, (System.nanoTime() - startTime) / 1000000, numberOfLoops, "Selection Sort", reversed);
    }
    
}
