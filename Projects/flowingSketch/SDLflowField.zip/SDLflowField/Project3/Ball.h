#pragma once

#include "Point.h"
#include "SDL.h"
#include "VectorValue.h"
#include "Color.h"

class Ball {
public:

	Ball(Point _position, float _force, Color _color);
	Ball(Point _position, Color _color);

	void updatePhysics();
	void render(SDL_Renderer *ren);

	static void setTarget(Point _target);

	VectorValue* getVelocityPointer();
	Point* getPositionPointer();
	static Point* getTargetPointer();

private:
	Point position, previousPosition;
	VectorValue velocity;
	Color color;
	static Point target;
	float force;
	float drag;

	void causeDrag();
	void limitVelocity();
	void pushTowardTarget();
	void moveBasedOnVelocity();
};