#include <iostream>
#include <SDL.h>
#include <Math.h>
#include <vector>
#include <random>
#include "Ball.h"
#include "Point.h"
#include "RandomExt.h"
#include <string>

SDL_Window *window;
SDL_Renderer *renderer;

int previousTick = 0;
const static int TARGET_FPS = 60;
const static int TARGET_FRAME_DIFFERENCE = 1000 / TARGET_FPS;
VectorValue velocity = VectorValue(0, 0);
int mouseX;
int mouseY;

std::vector<Ball> balls = std::vector<Ball>();

bool running = true;
SDL_Event event = SDL_Event();


/*
---------- ARTISTIC VARIABLES -----------
*/

static bool showTarget;
static Color targetColor = Color(0, 0, 0, 0);
static float maximumTargetVelocity;
static float targetMovementForce;
static Point initialTargetPosition = Point(0, 0);
static float targetDrag;

static int minRedBallColor;
static int maxRedBallColor;

static int minGreenBallColor;
static int maxGreenBallColor;

static int minBlueBallColor;
static int maxBlueBallColor;

static int minAlphaBallColor;
static int maxAlphaBallColor;

static int numberOfBalls;
static float minimumBallForce;
static float maximumBallForce;
static float maximumBallVelocity;

static int minimumStartingX;
static int minimumStartingY;
static int maximumStartingX;
static int maximumStartingY;


//-----------------------------------------


Point targetPreviousPosition = initialTargetPosition;
void renderTarget() {
	SDL_SetRenderDrawColor(renderer, targetColor.getR(), targetColor.getG(), targetColor.getB(), targetColor.getA());
	SDL_RenderDrawLine(renderer, Ball::getTargetPointer()->getX(), Ball::getTargetPointer()->getY(), targetPreviousPosition.getX(), targetPreviousPosition.getY());
	targetPreviousPosition = *Ball::getTargetPointer();
}

void renderBalls() {
	for (int i = 0; i < balls.size(); i++) {
		balls.at(i).render(renderer);
	}
}

void updateBallPhysics() {
	for (int i = 0; i < balls.size(); i++) {
		balls.at(i).updatePhysics();
	}
}

void updateTargetMovement() {
	if (velocity.getMagnitude() > maximumTargetVelocity) velocity.setMagnitude(maximumTargetVelocity);
	velocity.setMagnitude(velocity.getMagnitude() - targetDrag);
	if (velocity.getMagnitude() < 0) velocity.setMagnitude(0);
	if (SDL_GetMouseState(&mouseX, &mouseY) && SDL_BUTTON(SDL_BUTTON_LEFT)) {
		velocity.addVector(VectorValue(targetMovementForce, VectorValue::getAngleFromComponents(mouseX - Ball::getTargetPointer()->getX(), mouseY - Ball::getTargetPointer()->getY())));
	}
	Ball::setTarget(Point(Ball::getTargetPointer()->getX() + velocity.getXcomp(), Ball::getTargetPointer()->getY() + velocity.getYcomp()));
}

void handleKeyboardEvents() {

	const Uint8* keyboardState = SDL_GetKeyboardState(NULL);

	if (keyboardState[SDL_SCANCODE_W]) {
		velocity.addVector(VectorValue(targetMovementForce, 3 * 3.14159 / 2));
	}
	else if (keyboardState[SDL_SCANCODE_S]) {
		velocity.addVector(VectorValue(targetMovementForce, 3.14159 / 2));
	}

	if (keyboardState[SDL_SCANCODE_A]) {
		velocity.addVector(VectorValue(targetMovementForce, 3.14159));
	}
	else if (keyboardState[SDL_SCANCODE_D]) {
		velocity.addVector(VectorValue(targetMovementForce, 0));
	}

}

void handleEvents() {
	handleKeyboardEvents();

	while (SDL_PollEvent(&event) != 0) {
		if (event.type == SDL_QUIT) running = false;
	}
}


int frameDifference;
void limitFrameRate() {
	frameDifference = SDL_GetTicks() - previousTick;
	if (frameDifference < TARGET_FRAME_DIFFERENCE) {
		SDL_Delay(TARGET_FRAME_DIFFERENCE - frameDifference);
	}
	previousTick = SDL_GetTicks();
}

void mainloop() {
	while (running) {

		limitFrameRate();
		handleEvents();
		updateTargetMovement();
		updateBallPhysics();
		renderBalls();

		if (showTarget) renderTarget();

		SDL_PumpEvents();
		SDL_RenderPresent(renderer);
	}
}

void setupTarget() {
	Ball::setTarget(Point(initialTargetPosition));
}

float generateBallMovementForce() {
	return RandomExt::randRange(minimumBallForce, maximumBallForce);
}


Point generateBallStartingPosition() {
	float x = RandomExt::randRange(minimumStartingX, maximumStartingX, 0);
	float y = RandomExt::randRange(minimumStartingY, maximumStartingY, 0);
	return Point(x, y);
}

Color generateBallColor() {
	int red = RandomExt::randRange(minRedBallColor, maxRedBallColor, 0);
	int green = RandomExt::randRange(minGreenBallColor, maxGreenBallColor, 0);
	int blue = RandomExt::randRange(minBlueBallColor, maxBlueBallColor, 0);
	int alpha = RandomExt::randRange(minAlphaBallColor, maxAlphaBallColor, 0);
	return Color(red, green, blue, alpha);
}

Ball generateBall() {
	Color color = generateBallColor();
	Point position = generateBallStartingPosition();
	float force = generateBallMovementForce();
	return Ball(position, force, color);
}

void generateBallsForSimulation() {
	for (int i = 0; i < numberOfBalls; i++) {
		balls.push_back(generateBall());
	}
}

void initializeSDL() {
	int flags = SDL_RENDERER_ACCELERATED;
	SDL_Init(SDL_INIT_EVERYTHING);
	window = SDL_CreateWindow("title", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 750, 650, SDL_WINDOW_SHOWN);
	renderer = SDL_CreateRenderer(window, 0, flags);
	SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_ADD);
}

void initialize() {
	initializeSDL();
	generateBallsForSimulation();
	setupTarget();
}

float getNumberInput(std::string prompt) {
	std::string tmp;
	do {
		std::cout << prompt;
		std::cin >> tmp;
	} while (atof(tmp.c_str()) == 0 && tmp.at(0) != '0');

	return atof(tmp.c_str());
}

bool getBooleanInput(std::string prompt) {
	std::string tmp;
	do {
		std::cout << prompt + "(T/F): ";
		std::cin >> tmp;
	} while (tmp != "T" && tmp != "F" && tmp != "t" && tmp != "f");

	bool toReturn;
	if (tmp == "t" || tmp == "T") toReturn = true;
	if (tmp == "f" || tmp == "F") toReturn = false;

	return toReturn;
}

void getUserInputs() {
	showTarget = getBooleanInput("Show Target");
	std::cout << "Target Color" << std::endl;
	targetColor = Color(getNumberInput("Red: "), getNumberInput("Green: "), getNumberInput("Blue: "), getNumberInput("Alpha: "));
	maximumTargetVelocity = getNumberInput("Max Target Velocity: ");
	targetMovementForce = getNumberInput("Target Movement Force: ");
	std::cout << "Initial target position" << std::endl;
	int tempX = getNumberInput("x: ");
	int tempY = getNumberInput("y: ");
	initialTargetPosition = Point(tempX, tempY);
	targetDrag = getNumberInput("Target drag: ");

	minRedBallColor = getNumberInput("min red ball color: ");
	maxRedBallColor = getNumberInput("max red ball color: ");

	minGreenBallColor = getNumberInput("min green ball color: ");;
	maxGreenBallColor = getNumberInput("max green ball color: ");;

	minBlueBallColor = getNumberInput("min blue ball color: ");;
	maxBlueBallColor = getNumberInput("max blue ball color: ");;

	minAlphaBallColor = getNumberInput("min alpha ball color: ");;
	maxAlphaBallColor = getNumberInput("max alpha ball color: ");;

	numberOfBalls = getNumberInput("Number of balls to spawn: ");
	minimumBallForce = getNumberInput("Minimum ball force: ");
	maximumBallForce = getNumberInput("Maximum ball force: ");
	maximumBallVelocity = getNumberInput("Maximum ball velocity: ");

	minimumStartingX = getNumberInput("Minimum ball starting X: ");
	minimumStartingY = getNumberInput("Minimum ball starting Y: ");
	maximumStartingX = getNumberInput("Maximum ball starting X: ");
	maximumStartingY = getNumberInput("Maximum ball starting Y: ");
}

int main (int argc, char* argv[]){

	getUserInputs();
	initialize();
	mainloop();

	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);
	SDL_Quit();

	return 0;

}
