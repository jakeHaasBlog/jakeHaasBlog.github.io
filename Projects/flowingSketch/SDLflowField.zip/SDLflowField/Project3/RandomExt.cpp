#include "RandomExt.h"


float RandomExt::randRange(float min, float max, int decimalPlaces){
	int inflation = 1;
	for (int i = 0; i < decimalPlaces; i++) {
		inflation = inflation * 10;
	}
	int range = (max - min) * inflation;
	if (range > 0) {
		float rangeValue = ((float)(rand() % range)) / inflation;
		return rangeValue + min;
	}
	else {
		return min;
	}

}
