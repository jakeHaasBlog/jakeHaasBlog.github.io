#include "VectorValue.h"
#include <math.h>

VectorValue::VectorValue(float _magnitude, float _direction): magnitude(_magnitude), direction(_direction){

}

void VectorValue::addVector(VectorValue vect){

	float totalX = getXcomp() + vect.getXcomp();
	float totalY = getYcomp() + vect.getYcomp();
	direction = getAngleFromComponents(totalX, totalY);
	magnitude = sqrt(totalX*totalX + totalY*totalY);
	
}

void VectorValue::setMagnitude(float _magnitude){
	magnitude = _magnitude;
}

void VectorValue::setDirection(float _direction){
	direction = _direction;
}

float VectorValue::getMagnitude(){
	return magnitude;
}

float VectorValue::getDirection(){
	return direction;
}

float VectorValue::getXcomp() {
	return cos(direction) * magnitude;
}

float VectorValue::getYcomp() {
	return sin(direction) * magnitude;
}

float VectorValue::getAngleFromComponents(float xComp, float yComp){

	if (xComp > 0) {
		return atan(yComp/xComp);
	}
	else if (xComp < 0) {
		return atan(yComp / xComp) + 3.14159f;
	}
	else {
		if (yComp > 0) {
			return 3.14159f / 2;
		}
		else if (yComp < 0){
			return 3 / 2 * 3.14159f;
		}
		else {
			return 0;
		}
	}

}
