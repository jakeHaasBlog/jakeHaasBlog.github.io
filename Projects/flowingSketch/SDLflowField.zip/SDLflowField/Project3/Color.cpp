#include "Color.h"



Color::Color(int _r, int _g, int _b, int _a):
r(_r),
g(_g),
b(_b),
a(_a){}

void Color::setR(int _r){
	r = _r;
}

void Color::setG(int _g){
	g = _g;
}

void Color::setB(int _b) {
	b = _b;
}

void Color::setA(int _a) {
	a = _a;
}

int Color::getR(){
	return r;
}

int Color::getG() {
	return g;
}

int Color::getB() {
	return b;
}

int Color::getA() {
	return a;
}
