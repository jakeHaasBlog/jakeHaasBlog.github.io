#pragma once
class Point {

public:
	Point(float _x, float _y);

	float getX();
	float getY();

	void setX(float _x);
	void setY(float _y);

private:
	float x, y;
};

