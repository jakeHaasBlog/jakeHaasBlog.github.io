
#include "Ball.h"

Ball::Ball(Point _position, float _force, Color _color) :
	position(_position),
	previousPosition(_position),
	velocity(VectorValue(0, 0)),
	force(_force),
	color(_color),
	drag(0.05f)
{}

Point Ball::target = Point(0, 375);

VectorValue * Ball::getVelocityPointer(){
	
	return &velocity;
}

Point* Ball::getPositionPointer() {

	return &position;
}

void Ball::updatePhysics() {

	causeDrag();
	limitVelocity();
	pushTowardTarget();
	moveBasedOnVelocity();
}

void Ball::causeDrag() {
	velocity.addVector(VectorValue(drag, velocity.getDirection() + (2 * 3.14159)));
}

void Ball::limitVelocity() {
	if (velocity.getMagnitude() > 4) velocity.setMagnitude(4);
}

void Ball::pushTowardTarget() {
	float deltaX = velocity.getXcomp();
	float deltaY = velocity.getYcomp();

	float xToCenter = target.getX() - position.getX();
	float yToCenter = target.getY() - position.getY();

	velocity.addVector(VectorValue(force, VectorValue::getAngleFromComponents(xToCenter, yToCenter)));
}

void Ball::moveBasedOnVelocity() {
	position.setX(position.getX() + velocity.getXcomp());
	position.setY(position.getY() + velocity.getYcomp());
}

void Ball::render(SDL_Renderer *ren) {

	SDL_SetRenderDrawColor(ren, color.getR(), color.getG(), color.getB(), color.getA());
	SDL_RenderDrawLine(ren, previousPosition.getX(), previousPosition.getY(), position.getX(), position.getY());

	previousPosition = position;
}

void Ball::setTarget(Point _target){
	target = _target;
}

Point * Ball::getTargetPointer(){
	return &target;
}
