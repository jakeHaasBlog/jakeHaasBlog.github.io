#pragma once

#include <random>

static class RandomExt {

public:
	static float randRange(float min, float max, int decimalPlaces = 3);

};

