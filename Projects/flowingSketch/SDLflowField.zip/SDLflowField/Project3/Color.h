#pragma once

struct Color {
public:
	Color(int r, int g, int b, int a);

	void setR(int r);
	void setG(int g);
	void setB(int b);
	void setA(int a);

	int getR();
	int getG();
	int getB();
	int getA();

private:
	int r, g, b, a;

};

