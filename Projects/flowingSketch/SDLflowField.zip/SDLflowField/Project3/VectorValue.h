#pragma once
class VectorValue {

public:
	VectorValue(float _magnitude, float _direction);

	void addVector(VectorValue vect);

	void setMagnitude(float _magnitude);
	void setDirection(float _direction);

	float getMagnitude();
	float getDirection();
	float getXcomp();
	float getYcomp();

	static float getAngleFromComponents(float xComp, float yComp);

private:
	float magnitude, direction;

};

