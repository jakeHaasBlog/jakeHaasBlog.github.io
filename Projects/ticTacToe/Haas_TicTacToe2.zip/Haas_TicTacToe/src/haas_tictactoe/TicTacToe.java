
package Haas_TicTacToe;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;



/*
 *   Author: Jake Haas
 *   Developed: October 12, 2018
 *
 *   Decription: A game of tic-tac-toe. Each player takes a turn one after another, starting with X
 *               and moving to O. When a straight line three pieces long is made by a player they win.
 *               This program has buttons for playing against another player, or against an AI. The AI
 *               has settings for easy, medium, and hard. Easy places pieces randomly, medium has a 90%
 *               chance of placing the perfect move, and hard always moves perfectly. Tic-Tac-Toe is
 *               a "solved" game, meaning it it possible to never lose, only ever tie, or win. The hard
 *               difficulty setting attempts to implement this, but I didn't use a proven algorithm so it
 *               "might" be possible to beat, although after many, many trials I highly doubt it.
 *
 *
 */



public class TicTacToe {
    
    // create instance of my PaintedButtonClass for reset button
    public static PaintedButton reset;
    
    // create instances of my PaintedToggleButtonClass for game mode buttons
    public static PaintedToggleButton gameModePlayer;
    public static PaintedToggleButton gameModeAI;
    
    // create instances of my PaintedToggleButtonClass for difficulty buttons
    public static PaintedToggleButton difficultyButtonEasy;
    public static PaintedToggleButton difficultyButtonMedium;
    public static PaintedToggleButton difficultyButtonHard;
    
    // declare and initialize variables to hold score
    public static int scoreX = 0;
    public static int scoreO = 0;
    
    // Declares a bufferedImage to display when the player or A.I wins
    public static BufferedImage messageDisplay = new BufferedImage(600, 600, BufferedImage.TYPE_INT_ARGB);
    public static boolean showMessage = false;
    
    // declare int to hold which piece won the game  0: none/draw  1: X,  2: O
    // checkPiece is a utility I declared to hold 
    private static int checkPiece;
    public static int winPiece = 0;
   
    public static void main(String[] args) {
        
        // initializes the Game
        Game.init();
        
        //calls initilizeComponents
        initializeComponents();
        
        // runs the mainloop
        mainloop();
        
    }
    
    private static void initializeComponents(){
        // initializes the reset button using my PaintedButton class
        reset = new PaintedButton(755, 100, 80, 30, "Reset");
        // adds an action listener with method for reseting the game
        reset.addClickListener(()->{
            // when the reset button is clicked
            for (int x = 0; x < 3; x++){
                for (int y = 0; y < 3; y++){
                    // sets all pieced to none 
                    Game.markers[x][y].placed = 0;
                }
            }
            
            // stops the win/loss message from displaying
            showMessage = false;
            
            // adds one to score for winning piece
            if (winPiece == 1) scoreX++;
            if (winPiece == 2) scoreO++;
            
            // sets the winning piece to none
            winPiece = 0;
        });
        
        // Initializes the game mode toggle buttons
        gameModePlayer = new PaintedToggleButton(665, 150, 125, 25, "Two Player");
        gameModeAI = new PaintedToggleButton(805, 150, 125, 25, "Single player");
        gameModePlayer.addClickListener(()->{
            // when the single player toggle is pressed, unpress the other button
            gameModeAI.pressed = false;
            gameModePlayer.pressed = true;
        });
        gameModeAI.addClickListener(()->{
            // when the single player toggle is pressed, unpress the other button
            gameModePlayer.pressed = false;
            gameModeAI.pressed = true;
        });
        
        // initialize the game with single player selected
        gameModePlayer.pressed = true;
        
        // initialize the difficulty toggle buttons
        difficultyButtonEasy = new PaintedToggleButton(650, 200, 75, 25, "Easy");
        difficultyButtonMedium = new PaintedToggleButton(770, 200, 75, 25, "Medium");
        difficultyButtonHard = new PaintedToggleButton(890, 200, 75, 25, "Hard");
        difficultyButtonEasy.pressed = true;
        difficultyButtonEasy.addClickListener(()->{
            // when the easy player toggle is pressed, unpress the other difficulty buttons
            difficultyButtonEasy.pressed = true;
            difficultyButtonMedium.pressed = false;
            difficultyButtonHard.pressed = false;
        });
        difficultyButtonMedium.addClickListener(()->{
            // when the medium player toggle is pressed, unpress the other difficulty buttons
            difficultyButtonEasy.pressed = false;
            difficultyButtonMedium.pressed = true;
            difficultyButtonHard.pressed = false;
        });
        difficultyButtonHard.addClickListener(()->{
            // when the hard player toggle is pressed, unpress the other difficulty buttons
            difficultyButtonEasy.pressed = false;
            difficultyButtonMedium.pressed = false;
            difficultyButtonHard.pressed = true;
        });
    }
    
    private static void mainloop(){
        
        double currentTime;
        double startTime = System.currentTimeMillis();
        final double BETWEEN_FRAMES = 1000/60;
        

        while (true) {
            
            // limits the frame rate to 60FPS by finding the difference in time between start of frame and current time
            // if there is time to spare between frames it loops checking what the current time is and if it can move on to next frame
            do {
                currentTime = System.currentTimeMillis();
            } while(currentTime - startTime <= BETWEEN_FRAMES);
            startTime = System.currentTimeMillis();
            
            // repaints all components
            Game.drawBackground();
            Game.drawPieces();
            Game.drawMenu();
            
            // draws all painted buttons
            for (PaintedButton b: PaintedButton.allButtons) b.updateAndDraw();
            
            // for every piece see if it causes a win
            for (int x = 0; x < 3; x++){
                for (int y = 0; y < 3; y++){
                    // hold the piece you are checking: 0, 1, 0r 2
                    checkPiece = Game.markers[x][y].placed;
                    // if the piece is not an empty space
                    if (checkPiece != 0){
                        // if the piece causes a win
                        if (willWinGame(checkPiece, x, y)) {
                            // show victory message and set winPiece to the piece that was being checked
                            showMessage = true;
                            winPiece = checkPiece;
                        }
                    }
                }
            }
            
            // count and store how many pieces are on the board
            int numOfPieces = 0;
            for (int x = 0; x < 3; x++){
                for (int y = 0; y < 3; y++){
                    // ignore blank spaces
                    if (Game.markers[x][y].placed != 0) numOfPieces++;
                }
            }
        
            // show a message when you win, lose, or draw
            if (showMessage){
                
                // creates a graphics context for the message display
                Graphics messageGraphics = messageDisplay.getGraphics();
                // cover the board with black
                messageGraphics.setColor(new Color(0, 0, 0, 255));
                messageGraphics.fillRect(0, 0, 600, 600);
                // set the font to be red dialogue
                messageGraphics.setColor(Color.red);
                messageGraphics.setFont(new Font(Font.DIALOG, Font.BOLD, 40));
                
                // depending on the piece that caused the win write victory, loss or draw on message bufferedImage
                if (winPiece == 1) {
                    // x won, display player wins and new score
                    messageGraphics.drawString("Player wins!", 200, 300);
                    messageGraphics.drawString((scoreX + 1) +" - " + scoreO, 270, 370);
                } else if (winPiece == 2){
                    // o won
                    if (gameModePlayer.pressed){
                        // if playing two-player display opponent won
                        messageGraphics.drawString("Opponent wins!", 200, 300);
                        messageGraphics.drawString(scoreX + " - " + (scoreO + 1), 270, 370);
                    } else {
                        // if playing against the AI display computer wins
                        messageGraphics.drawString("Computer wins!", 200, 300);
                        messageGraphics.drawString(scoreX + " - " + (scoreO + 1), 270, 370);
                    }
                } else {
                    // it was a draw
                    messageGraphics.drawString("Draw!", 250, 300);
                    messageGraphics.drawString(scoreX + " - " + scoreO, 270, 370);
                }
                
                // draw the message on the screen over the board
                Game.display.getGraphicsContext().drawImage(messageDisplay, 0, 0, null);
                

            } else {
                // if not displaying a win message display board, and run game logic
                
                // overrite the old message in case somebody wins this frame
                messageDisplay = new BufferedImage(600, 600, BufferedImage.TYPE_INT_ARGB);
                
                // if the board is full show the win message with a winning piece of neither x or o
                if (numOfPieces == 9){
                    showMessage = true;
                    winPiece = 0;
                }   

                // runs game logic
                
                // holds the move most likely to make the opponent win
                Point idealPlay;
                // if two player is selected
                if (gameModePlayer.pressed){
                    // run two player game logic
                    twoPlayerLogic();
                } else {
                    // otherwise it is one player against AI
                    
                    // sets player piece to x
                    Game.currentPlayer = 1;
                    
                    // stores amount of x's and o's on board
                    int numberOfXs = 0;
                    int numberOfOs = 0;
                    for (int x = 0; x < 3; x++){
                        for (int y = 0; y < 3; y++){
                            if (Game.markers[x][y].placed == 1) numberOfXs++;
                            else if (Game.markers[x][y].placed == 2) numberOfOs++;
                        }
                    }
                    int numberOfPieces = numberOfOs + numberOfXs;
                    
                    // if there are more x's than there are o's it is the AI's turn
                    if (numberOfXs > numberOfOs){
                        
                        // if the difficulty is easy
                        if (difficultyButtonEasy.pressed){ 
                            if (numberOfPieces <= 8){
                                // place o at random spot on board
                                Point randomPoint = findRandomPoint();
                                Game.markers[randomPoint.x][randomPoint.y].placed = 2;
                            }
                        } 
                        // if the difficulty is medium
                        else if (difficultyButtonMedium.pressed){
                            if (numberOfPieces <= 8){
                                
                                // finds the perfect move
                                idealPlay = findPerfectMove();
                                
                                if (Math.random()*10 >= 8){
                                    // place piece randomly 20% of the time
                                    Point randomPoint = findRandomPoint();
                                    Game.markers[randomPoint.x][randomPoint.y].placed = 2;
                                } else {
                                    // place piece perfectly 80% of the rime
                                    Game.markers[idealPlay.x][idealPlay.y].placed = 2;
                                }
                            }
                        } 
                        // if the difficulty is hard
                        else {
                            if (numberOfPieces <= 8){
                                // plays the perfect move evey time, this AI is impossible to beat
                                idealPlay = findPerfectMove();
                                Game.markers[idealPlay.x][idealPlay.y].placed = 2;
                            }
                        }
                    }
                }
            }
            // repaints the static JFrame
            Game.display.repaint();
        }
    }
    
    /** runs in a loop to cause a two player game */
    public static void twoPlayerLogic(){
        
        // stores the number of x's and o's on the board
        int numberOfXs = 0;
        int numberOfOs = 0;
        for (int x = 0; x < 3; x++){
            for (int y = 0; y < 3; y++){
                if (Game.markers[x][y].placed == 1) numberOfXs++;
                else if (Game.markers[x][y].placed == 2) numberOfOs++;
            }
        }
        
        // if there are less than or equal x's as o's it is x's turn
        if (numberOfXs <= numberOfOs) Game.currentPlayer = 1;
        // otherwise it is o's turn
        else Game.currentPlayer = 2;
    }
    
    /** finds the move most likely to win the game */
    public static Point findPerfectMove(){
        
        // store the best place to move to
        Point bestMove = findRandomPoint();
        
        // stores number of o's on the board
        int numberOfOs = 0;
        for (int x = 0; x < 3; x++){
            for (int y = 0; y < 3; y++){
                if (Game.markers[x][y].placed == 2) numberOfOs++;
            }
        }
        
        // if it is the first move for o, try to go to the center
        if (numberOfOs == 0){
            if (Game.markers[1][1].placed == 0){
                bestMove = new Point(1, 1);
            }
        }
        
        // if it is the second move for o, go to any side 
        if (numberOfOs == 1 && Game.markers[1][1].placed == 2){
            // holds all sides
            Point sides[] = {new Point(0, 1), new Point(1, 0), new Point(1, 2), new Point(2, 1)};
            Point p;
            // picks a random side until it finds an unocupied side
            do {
                p = sides[(int)(Math.random()*4)];
            } while (Game.markers[p.x][p.y].placed != 0);
            // the best move is then the chosen side
            bestMove = p;
        }
        
        // for every spot, if placing an x will win the game place an o there, blocking the player from winning
        for (int x = 0; x < 3; x++){
            for (int y = 0; y < 3; y++){
                if (Game.markers[x][y].placed == 0){
                    if (willWinGame(1, x, y)){
                        bestMove = new Point(x, y);
                    }
                }
            }
        }
        
        // for every spot, if placing an o there will win the game place an o there
        for (int x = 0; x < 3; x++){
            for (int y = 0; y < 3; y++){
                if (Game.markers[x][y].placed == 0){
                    if (willWinGame(2, x, y)){
                        bestMove = new Point(x, y);
                    }
                }
            }
        }
        
        // if it is o's first move and there is an x in the center place an o in a corner
        if (numberOfOs == 0){
            if (Game.markers[1][1].placed == 1){
                Point corners[] = {new Point(0, 0), new Point(2, 0), new Point(0, 2), new Point(2, 2)};
                bestMove = corners[(int)(Math.random()*4)];
            }
        }
        
        // if it is o's second move and there is an x in the center, and an x in any corner, place an o in any corner
        if (numberOfOs == 1){
            if (Game.markers[1][1].placed == 1){
                boolean xInCorner = false;
                if (Game.markers[0][0].placed == 1) {
                    if (Game.markers[2][2].placed == 2){
                        xInCorner = true;
                    }
                }
                if (Game.markers[2][0].placed == 1) {
                    if (Game.markers[0][2].placed == 2){
                        xInCorner = true;
                    }
                }
                if (Game.markers[0][2].placed == 1) {
                    if (Game.markers[2][0].placed == 2){
                        xInCorner = true;
                    }
                }
                if (Game.markers[2][2].placed == 1) {
                    if (Game.markers[0][0].placed == 2){
                        xInCorner = true;
                    }
                }
                
                if (xInCorner){
                    // place an o in any corner
                    Point corners[] = {new Point(0, 0), new Point(0, 2), new Point(2, 0), new Point(2, 2)};
                    Point p;
                    do {
                        p = corners[(int)(Math.random()*4)];
                    } while (Game.markers[p.x][p.y].placed != 0);
                    bestMove = p;
                }
            }
        }
        
        // returns the place determined to be the most likely to win
        return bestMove;
    }
    
    /** returns wither or not placing a piece at a point will cause a win for that player or AI */
    public static boolean willWinGame(int piece, int x, int y){
        
        // store if point will cause win or not
        boolean win = false;
        
        // checks if any two connecting pieces will cause a win
        try { if (Game.markers[x+1][y].placed == piece && Game.markers[x+2][y].placed == piece) win = true; } catch (Exception e){}
        try { if (Game.markers[x-1][y].placed == piece && Game.markers[x-2][y].placed == piece) win = true; } catch (Exception e){}
        try { if (Game.markers[x][y+1].placed == piece && Game.markers[x][y+2].placed == piece) win = true; } catch (Exception e){}
        try { if (Game.markers[x][y-1].placed == piece && Game.markers[x][y-2].placed == piece) win = true; } catch (Exception e){}
        try { if (Game.markers[x+1][y+1].placed == piece && Game.markers[x+2][y+2].placed == piece) win = true; } catch (Exception e){}
        try { if (Game.markers[x-1][y-1].placed == piece && Game.markers[x-2][y-2].placed == piece) win = true; } catch (Exception e){}
        try { if (Game.markers[x+1][y-1].placed == piece && Game.markers[x+2][y-2].placed == piece) win = true; } catch (Exception e){}
        try { if (Game.markers[x-1][y+1].placed == piece && Game.markers[x-2][y+2].placed == piece) win = true; } catch (Exception e){}
        try { if (Game.markers[x-1][y].placed == piece && Game.markers[x+1][y].placed == piece) win = true; } catch (Exception e){}
        try { if (Game.markers[x-1][y-1].placed == piece && Game.markers[x+1][y+1].placed == piece) win = true; } catch (Exception e){}
        try { if (Game.markers[x-1][y+1].placed == piece && Game.markers[x+1][y-1].placed == piece) win = true; } catch (Exception e){}
        try { if (Game.markers[x][y-1].placed == piece && Game.markers[x][y+1].placed == piece) win = true; } catch (Exception e){}
        try { if (Game.markers[x][y-1].placed == piece && Game.markers[x][y+1].placed == piece) win = true; } catch (Exception e){}
        
        // returns if piece will cause win or not
        return win;
    }
    
    /** returns a random point on board that is not covering any existing pieces */
    public static Point findRandomPoint(){
        int randomX;
        int randomY;
        // loop until the random coordinates fall on a blank space
        do {
            randomX = (int)(Math.random()*3);
            randomY = (int)(Math.random()*3);
        } while (Game.markers[randomX][randomY].placed != 0);
        
        // return the randomly chosen point
        return new Point(randomX, randomY);
    }
 
    // a small struct to hold an x, and y coordinate (in c++ they were called structs, im not sure if they are in java though...)
    static class Point{
        public int x, y;
        public Point(int _x, int _y){
            x = _x;
            y = _y;
        }
    }
    
}