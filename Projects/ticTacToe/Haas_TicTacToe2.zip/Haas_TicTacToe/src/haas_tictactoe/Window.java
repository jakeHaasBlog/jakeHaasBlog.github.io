
package Haas_TicTacToe;

import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import javax.swing.JFrame;
import javax.swing.event.MouseInputListener;

public class Window extends JFrame{
    
    // declares the frame that covers the whole screen 
    private BufferedImage frame = new BufferedImage(1000, 600, BufferedImage.TYPE_INT_RGB);
    private Graphics frameContext;
    
    // holds the mouse x, y position, and if it is pressed down or not
    public static int mouseX = 0;
    public static int mouseY = 0;
    public static boolean mouseDown = false;
    
    /** constructor sets standard properties for a JFrame */
    public Window(){
        setTitle("Tic-Tac-Toe");
        setSize(1000, 600);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        
        // stores the graphics context from the main frame image
        frameContext = frame.getGraphics();
        
        // creates and adds a MouseInputListener to get motion events and press/release events
        MyMouseListener mouseListener = new MyMouseListener();
        addMouseListener(mouseListener);
        addMouseMotionListener(mouseListener);
    }
    
    @Override
    /** overrides the paint method to draw the main frame when repainted */
    public void paint(Graphics g){
        g.drawImage(frame, 0, 0, null);
    }

    /** returns the graphics context for the main frame */
    public Graphics getGraphicsContext(){
        return frameContext;
    }
    
}

/**  Implements the MouseInputListener which includes methods for mouse motion, and press/release  */
class MyMouseListener implements MouseInputListener{

    /** when the mouse is pressed set mouseDown variable to down */
    public void mousePressed(MouseEvent me) {
        Window.mouseDown = true;
    }

    /** when the mouse is pressed set mouseDown variable to down */
    public void mouseReleased(MouseEvent me) {
        Window.mouseDown = false;
    }

    /** when mouse is dragged set mouse position to event position */
    public void mouseDragged(MouseEvent me) {
        Window.mouseX = me.getX();
        Window.mouseY = me.getY();
    }

    /** when mouse is moved set mouse position to event position */
    public void mouseMoved(MouseEvent me) {
        Window.mouseX = me.getX();
        Window.mouseY = me.getY();
    }
    
    // these methods must be implemented, but they are not neccisary in this program
    public void mouseClicked(MouseEvent me) {}
    public void mouseEntered(MouseEvent me) {}
    public void mouseExited(MouseEvent me) {}
}