
package Haas_TicTacToe;

import static Haas_TicTacToe.TicTacToe.scoreO;
import static Haas_TicTacToe.TicTacToe.scoreX;
import java.awt.Color;
import java.awt.Font;
import java.awt.image.BufferedImage;

// static class holding board and menu. Also methods for displaying unchanging components
public class Game {
    
    // declare a static window(extended JFrame)
    public static Window display = new Window();
    
    // a 2D array of PainedPiece objects to cover the board
    public static PaintedPiece markers[][] = new PaintedPiece[3][3];
    
    // buffered image to hold board graphics
    private static BufferedImage grid;
    
    // constants defined to make code more readable
    public static final int GAME_WIDTH = 600;
    public static final int GAME_HEIGHT = 600;
    public final static int pieceWidth = 150;
    public final static int pieceHeight = 150;
    private final static int pieceXoffset = 200;
    private final static int pieceYoffset = 200;
    
    public static int currentPlayer = 1;   // 1: x,  2: 0
    
    // static class cannot have a constructor, so init is nessisary to initialize the markers array
    public static void init(){
        // loads images for pieces
        loadImages();
        // initializes pieces into markers array
        for (int x = 0; x < 3; x++){
            for (int y = 0; y < 3; y++){
                markers[x][y] = new PaintedPiece(x * pieceXoffset, y * pieceYoffset, pieceWidth, pieceHeight);
            }
        }
    }
    
    private static void loadImages(){
        // initialize grid to board size
        grid = new BufferedImage(GAME_WIDTH, GAME_HEIGHT, BufferedImage.TYPE_INT_ARGB);
    }
    
    /** draws the background black and puts white grid on top of it */
    public static void drawBackground(){
        display.getGraphicsContext().setColor(Color.black);
        display.getGraphicsContext().fillRect(0, 0, GAME_HEIGHT, GAME_HEIGHT);
        
        display.getGraphicsContext().setColor(Color.white);
        display.getGraphicsContext().fillRect(GAME_WIDTH, 0, 400, GAME_HEIGHT);
        
        display.getGraphicsContext().setColor(Color.white);
        display.getGraphicsContext().fillRect(GAME_WIDTH / 3, 0, 10, GAME_HEIGHT);
        display.getGraphicsContext().fillRect((GAME_WIDTH / 3)*2, 0, 10, GAME_HEIGHT);
        display.getGraphicsContext().fillRect(0, GAME_HEIGHT/3, GAME_WIDTH, 10);
        display.getGraphicsContext().fillRect(0, (GAME_HEIGHT/3)*2, GAME_WIDTH, 10);
    }
   
    /** calls the updateAndDraw method for every method */
    public static void drawPieces(){
        for (int x = 0; x < 3; x++){
            for (int y = 0; y < 3; y++){
                markers[x][y].updateAndDraw();
            }
        }
    }
    
    /** draws the menu pieces that are not interactive */
    public static void drawMenu(){
        
        // draws title
        display.getGraphicsContext().setFont(new Font(Font.SERIF, Font.PLAIN, 30));
        display.getGraphicsContext().setColor(Color.BLACK);
        display.getGraphicsContext().drawString("Game Menu", 725, 80);
        
        // display score in menu area
        Game.display.getGraphicsContext().setColor(Color.black);
        Game.display.getGraphicsContext().drawString("Score: " + scoreX + " - " + scoreO, 730, 270);
            
    }
    
}