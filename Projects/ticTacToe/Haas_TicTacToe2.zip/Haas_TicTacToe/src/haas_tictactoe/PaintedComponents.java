
package Haas_TicTacToe;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;

// simular to a JButton but able to be painted onto a BufferedImage
class PaintedButton {
    // declare images for the button states, up, down, and being hovered over
    public BufferedImage up;
    protected BufferedImage down;
    protected BufferedImage mouseOver;
    
    // declare variable for the painted button pressed action interface 
    PaintedButtonListener listener;
    
    // declare position variables
    protected int x, y, width, height;
    
    // declare and initialize booleans to hold if the mouse was down, and over this button last frame
    protected boolean wasMouseDown = false;
    protected boolean wasMouseOver = false;
    
    // static array that holds every instance of this class
    public static ArrayList<PaintedButton> allButtons = new ArrayList<PaintedButton>();
    
    // constructor takes position and default text arguments
    public PaintedButton(int _x, int _y, int _width, int _height, String text){
        x = _x;
        y = _y;
        width = _width;
        height = _height;
        
        // create empty BufferedImages for button states
        up = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        down = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        mouseOver = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        
        // initializes the button state images to a default look
        setDefaultGraphics(text);
        
        // adds this button to the static arraylist of all buttons
        allButtons.add(this);
    }
    
    /** Draws default graphics for button states */
    public void setDefaultGraphics(String text){
        
        // gets graphics contexts from button state buffered images
        Graphics upGraphics = up.getGraphics();
        Graphics downGraphics = down.getGraphics();
        Graphics mouseOverGraphics = mouseOver.getGraphics();
        
        // draws button up grahics
        upGraphics.setColor(Color.black);
        upGraphics.fillRect(0, 0, width, height);
        upGraphics.setColor(Color.gray);
        upGraphics.fillRect(0, 0, width - 3, height - 3);
        upGraphics.setColor(Color.black);
        upGraphics.setFont(new Font(Font.DIALOG, Font.PLAIN, height - 4));
        upGraphics.drawString(text, 3, height - 3);
        
        // draws mouse over grahics
        mouseOverGraphics.setColor(Color.black);
        mouseOverGraphics.fillRect(0, 0, width, height);
        mouseOverGraphics.setColor(new Color(100, 100, 100));
        mouseOverGraphics.fillRect(0, 0, width - 3, height - 3);
        mouseOverGraphics.setColor(Color.black);
        mouseOverGraphics.setFont(new Font(Font.DIALOG, Font.PLAIN, height - 4));
        mouseOverGraphics.drawString(text, 3, height - 3);
        
        // draws button down grahics
        downGraphics.setColor(Color.black);
        downGraphics.fillRect(0, 0, width, height);
        downGraphics.setColor(new Color(100, 100, 100));
        downGraphics.fillRect(3, 3, width - 3, height - 3);
        downGraphics.setColor(Color.black);
        downGraphics.setFont(new Font(Font.DIALOG, Font.PLAIN, height - 4));
        downGraphics.drawString(text, 3, height - 3);
    }
    
    /** gets if the button was pressed, and draws the button onto the display held in the static Game class */
    public void updateAndDraw(){
        
        // stores if the mouse is over the button
        boolean mOver = false;
        if (x <= Window.mouseX && Window.mouseX <= x + width){
            if (y <= Window.mouseY && Window.mouseY <= y + height){
                mOver = true;
            }
        }
        
        // draws the button corrosponding to its state
        if (Window.mouseDown && mOver){
            Game.display.getGraphicsContext().drawImage(down, x, y, null);
        } else if (mOver){
            Game.display.getGraphicsContext().drawImage(mouseOver, x, y, null);
        } else {
            Game.display.getGraphicsContext().drawImage(up, x, y, null);
        }
        
        // gets if the mouse was pressed and then released while staying overtop the button
        if (wasMouseOver && wasMouseDown){
            if (!Window.mouseDown){
                // calls single method within paintedButtonListener for button pressed event
                try {listener.clicked();}catch(Exception e){}
            }
        }
        
        // sets if the mouse was over the button this frame, and if the mouse was down this frame
        wasMouseOver = mOver;
        wasMouseDown = Window.mouseDown;
        
    }
    
    /** method for adding a paintedButtonListener to be called when button is pressed */
    public void addClickListener(PaintedButtonListener _listener){
        listener = _listener;
    }
    
}

/** functional interface to be added to a PaintedButton that is called when the button is clicked */
interface PaintedButtonListener {
    // abstract method that must be overwriten before adding to a button
    abstract void clicked();
}

/**  This class is a button that toggles rather than presses   */
class PaintedToggleButton extends PaintedButton{
    
    // declare the state of the button
    public boolean pressed = false;
    
    // constructor calls the constructor in PaintedButton because it extends it to get default graphics
    public PaintedToggleButton(int _x, int _y, int _width, int _height, String text){
        super(_x, _y, _width, _height, text);
    }
    
    // overrides the update and draw to create a toggling behavior
    @Override
    public void updateAndDraw(){
        // stores if the mouse is over the button
        boolean mOver = false;
        if (x <= Window.mouseX && Window.mouseX <= x + width){
            if (y <= Window.mouseY && Window.mouseY <= y + height){
                mOver = true;
            }
        }
        
        // draw the corrosponding state, has no mouse over image
        if (pressed){
            Game.display.getGraphicsContext().drawImage(down, x, y, null);
        } else if (!pressed){
            Game.display.getGraphicsContext().drawImage(up, x, y, null);
        }
        
        // gets if the mouse was clicked and calls the overwritten method in the PaintedButtonListener
        if (wasMouseOver && wasMouseDown){
            if (!Window.mouseDown){
                // switches the state of the button when pressed
                pressed = !pressed;
                // calls overwritten method in functional interface
                try {listener.clicked();} catch (Exception e){}
            }
        }
        
        // sets if the mouse was over and if the mouse was down this frame
        wasMouseOver = mOver;
        wasMouseDown = Window.mouseDown;
    }
}

/** this class defines a piece, either an X or an O */
class PaintedPiece {
    
    // declare BufferedImages for the X and O pieces
    BufferedImage xPiece;
    BufferedImage oPiece;
    
    // declare position
    int x, y, width, height;
    
    // declare variables for if the mouse was down, and if the mouse was over the button
    protected boolean wasMouseDown = false;
    protected boolean wasMouseOver = false;
    
    // declare the piece that is placed here
    int placed = 0; // 0: none,  1: x,  2: o
    
    /** constructor sets position of pieces, and loads x and o images */
    public PaintedPiece(int _x, int _y, int _width, int _height){
        x = _x;
        y = _y;
        width = _width;
        height = _height;
        
        loadImages();
    }
    
    private void loadImages(){
        // create temporary images for pieces
        Image tmpXpiece = new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB);
        Image tmpYpiece = new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB);
        
        // try to load the x and o images, then scale them, if can't; display error messages
        try {
            tmpXpiece = ImageIO.read(new File("src/x-piece.png")).getScaledInstance(Game.pieceWidth, Game.pieceHeight, Image.SCALE_SMOOTH);
        } catch (IOException e) {
            System.out.println("Could not find image for x-piece");
        }
        try {
            tmpYpiece = ImageIO.read(new File("src/o-piece.png")).getScaledInstance(Game.pieceWidth, Game.pieceHeight, Image.SCALE_SMOOTH);
        } catch (IOException e) {
            System.out.println("Could not find image for o-piece");
        }
        
        // sets the final x and 0 images to the scaled version of the temporary images
        xPiece = new BufferedImage(Game.pieceWidth, Game.pieceHeight, BufferedImage.TYPE_INT_ARGB);
        xPiece.getGraphics().drawImage(tmpXpiece, 0, 0, null);
        
        oPiece = new BufferedImage(Game.pieceWidth, Game.pieceHeight, BufferedImage.TYPE_INT_ARGB);
        oPiece.getGraphics().drawImage(tmpYpiece, 0, 0, null);
    }
    
    /** gets if the piece was clicked, and draws the appropriate piece */
    public void updateAndDraw(){
        
        // stores if the mouse was over the piece or not
        boolean mOver = false;
        if (x <= Window.mouseX && Window.mouseX <= x + 200){
            if (y <= Window.mouseY && Window.mouseY <= y + 200){
                mOver = true;
            }
        }
        
        // displays either an x or an o depending on placed variable
        if (placed == 1){
            Game.display.getGraphicsContext().drawImage(xPiece, x + 30, y + 30, null);
        } else if (placed == 2){
            Game.display.getGraphicsContext().drawImage(oPiece, x + 30, y + 30, null);
        }
        
        // if the spot was clicked and it did not have a piece in it already, place the players piece
        if (wasMouseOver && wasMouseDown){
            if (!Window.mouseDown){
                if (placed == 0){
                    placed = Game.currentPlayer;
                }
            }
        }
        
        // set if the mouse was over the button, and down this frame
        wasMouseOver = mOver;
        wasMouseDown = Window.mouseDown;
    }
    
}