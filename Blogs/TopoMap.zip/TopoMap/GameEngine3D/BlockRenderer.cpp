

#include "BlockRenderer.h"

#include "gtc/matrix_transform.hpp"

const float BlockRenderer::vertices[] = {
	0,  0,
	1,  0,
	1, -1,
	0, -1,
};

const unsigned int BlockRenderer::indices[] = {
	0, 1, 2,
	0, 2, 3,
};

VertexBuffer* BlockRenderer::vb = nullptr;
IndexBuffer* BlockRenderer::ib = nullptr;
VertexArray* BlockRenderer::va = nullptr;
Shader* BlockRenderer::shader = nullptr;

float BlockRenderer::r = 1.0f;
float BlockRenderer::g = 1.0f;
float BlockRenderer::b = 1.0f;

void BlockRenderer::init() {
	vb = new VertexBuffer();
	vb->bufferData((void*)vertices, 4 * 2 * sizeof(float));

	ib = new IndexBuffer();
	ib->bufferData((void*)indices, 3 * 2 * sizeof(unsigned int));

	va = new VertexArray();
	va->setIndividualVertexBuffer(*vb, "ff");

	shader = new Shader("../assets/rectangle.sh");
}

void BlockRenderer::cleanup() 
{
	delete vb;
	delete ib;
	delete va;
	delete shader;
}


void BlockRenderer::setColor(float _r, float _g, float _b)
{
	r = _r;
	g = _g;
	b = _b;
}

void BlockRenderer::drawRectangle(float x, float y, float width, float height, glm::mat4 view, glm::mat4 proj)
{
	glm::mat4 model =
		glm::translate(glm::mat4(1.0f), glm::vec3(x, y, -5))
		*
		glm::scale(glm::mat4(1.0f), glm::vec3(width, height, 1));

	shader->setUniform3f("u_color", r, g, b);
	shader->setUniformMat4f("u_mvp", proj * view * model);

	shader->bind();

	va->bind();
	vb->bind();
	ib->bind();

	glDisable(GL_CULL_FACE);
	glDrawElements(GL_TRIANGLES, ib->getCount(), GL_UNSIGNED_INT, nullptr);
	glEnable(GL_CULL_FACE);
}