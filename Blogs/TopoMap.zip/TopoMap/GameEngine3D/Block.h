#pragma once

#include "glm.hpp"

class Block {
public:

	float x, y, width, height;
	int maxHealth;
	int health;

	bool detectCollision(float x, float y, float rad);
	bool detectCollision(const Block& b);
	bool containsPoint(float x, float y);

	void render(float r, float g, float b, const glm::mat4& viewMat, const glm::mat4& projMat);

};