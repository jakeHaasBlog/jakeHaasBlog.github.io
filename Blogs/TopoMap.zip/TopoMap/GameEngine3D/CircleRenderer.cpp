#include "CircleRenderer.h"

#include "VertexBuffer.h"
#include "VertexArray.h"
#include "IndexBuffer.h"
#include "Shader.h"

#include "gtc/matrix_transform.hpp"

float CircleRenderer::r = 1.0f;
float CircleRenderer::g = 1.0f;
float CircleRenderer::b = 1.0f;

void CircleRenderer::setColor(float _r, float _g, float _b)
{
	r = _r;
	g = _g;
	b = _b;
}

void CircleRenderer::renderEllipse(float x, float y, float width, float height, const glm::mat4& viewMatrix, const glm::mat4& projMatrix)
{
	static float vertices[8] = {
		-0.5f,  0.5f,
		 0.5f,  0.5f,
		 0.5f, -0.5f,
		-0.5f, -0.5f
	};

	static int indices[6] = {
		2, 0, 1,
		0, 2, 3
	};

	static VertexBuffer vb(vertices, 8 * sizeof(float));
	static IndexBuffer ib(indices, 6 * sizeof(unsigned int));
	static VertexArray va(vb, "ff");
	static Shader sh("../assets/circle.sh");


	glm::mat4 model =
		glm::translate(glm::mat4(1.0f), glm::vec3(x, y, -5))
		*
		glm::scale(glm::mat4(1.0f), glm::vec3(width, height, 1));

	sh.setUniform3f("u_color", r, g, b);
	sh.setUniformMat4f("u_mvp", projMatrix * viewMatrix * model);

	sh.bind();

	va.bind();
	vb.bind();
	ib.bind();

	glDisable(GL_CULL_FACE);
	glDrawElements(GL_TRIANGLES, ib.getCount(), GL_UNSIGNED_INT, nullptr);
	glEnable(GL_CULL_FACE);

}
