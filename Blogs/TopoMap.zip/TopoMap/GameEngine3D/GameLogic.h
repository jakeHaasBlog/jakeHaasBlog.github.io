#pragma once

#include <vector>

#include "glm.hpp"
#include "gtc/matrix_transform.hpp"

#include "GL/glew.h"
#include "GLFW/glfw3.h"

#define PIX_X ((int)(1920.0f * 1.5f))
#define PIX_Y ((int)(1080.0f * 1.5f))

class GameLogic {
public:

	static void init();
	static void update();
	static void render();
	static void cleanup();

	static glm::mat4 viewMatrix;
	static glm::mat4 projMatrix;

	static GLuint tex;

	static double perlinNoise(double x, double y);

private:
	static void loadTexturePixels(std::vector<std::array<float, 3>>& pixels);

	static std::vector<double> randomNumbers;
	static void loadRandomNumbers(std::vector<double>& numbers);

};