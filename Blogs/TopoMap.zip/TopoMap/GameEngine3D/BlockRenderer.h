#pragma once

#include "Shader.h"
#include "IndexBuffer.h"
#include "VertexBuffer.h"
#include "VertexArray.h"

class BlockRenderer {
private:
	const static float vertices[4 * 2];
	const static unsigned int indices[2 * 3];
	static VertexBuffer* vb;
	static IndexBuffer* ib;
	static VertexArray* va;
	static Shader* shader;

	static float r;
	static float g;
	static float b;

public:
	static void init();
	static void cleanup();

	static void setColor(float r, float g, float b);
	static void drawRectangle(float x, float y, float width, float height, glm::mat4 view, glm::mat4 proj);

};