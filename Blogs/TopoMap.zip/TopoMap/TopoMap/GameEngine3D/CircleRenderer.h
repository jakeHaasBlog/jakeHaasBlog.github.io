#pragma once

#include "glm.hpp"


class CircleRenderer {
private:
	static float r, g, b;

public:
	static void setColor(float r, float g, float b);
	static void renderEllipse(float x, float y, float width, float height, const glm::mat4& viewMatrix, const glm::mat4& projMatrix);

};