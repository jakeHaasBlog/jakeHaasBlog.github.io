#include "Block.h"
#include <math.h>

#include "BlockRenderer.h"

bool Block::detectCollision(float bx, float by, float brad)
{

	float DeltaX = bx - fmax(x, fmin(bx, x + width));
	float DeltaY = by - fmin(y, fmax(by, y - height));
	return (DeltaX * DeltaX + DeltaY * DeltaY) < (brad * brad);

}

bool Block::detectCollision(const Block & b)
{
	if (x < b.x + b.width &&
		x + width > b.x &&
		y < b.y + b.height &&
		y + height > b.y) 
	{
		return true;
	}

	return false;
}

bool Block::containsPoint(float _x, float _y)
{

	if (x <= _x && _x <= x + width) {
		if (y - height <= _y && _y <= y) {
			return true;
		}
	}

	return false;
}

void Block::render(float r, float g, float b, const glm::mat4& viewMat, const glm::mat4& projMat)
{
	BlockRenderer::setColor(r, g, b);
	BlockRenderer::drawRectangle(x, y, width, height, viewMat, projMat);
}
