
#include "VertexBufferLayout.h"

VertexBufferLayout::VertexBufferLayout()
	:stride(0)
{
}