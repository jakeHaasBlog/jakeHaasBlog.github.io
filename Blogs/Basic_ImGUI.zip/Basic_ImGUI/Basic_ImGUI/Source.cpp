#include <iostream>
#include <sstream>

#include "imgui.h"
#include "imgui_impl_glfw.h"
#include "imgui_impl_opengl3.h"

#include "GL/glew.h" // make sure these are included in this order!!
#include "GLFW/glfw3.h"


int main() {

	if (!glfwInit()) {
		std::cout << "GLFW did not initialize properly\n";
		return -1;
	}

	GLFWwindow* window = glfwCreateWindow(1080, 720, "ImGUI Example", nullptr, nullptr);
	glfwMakeContextCurrent(window);
	glfwSwapInterval(1); // this enables v-synk and locks window rendering to 60fps

	glewInit();

	ImGui::CreateContext();

	ImGui_ImplGlfw_InitForOpenGL(window, true);
	ImGui_ImplOpenGL3_Init("#version 130");

	float sliderValues[3] = { 0.0f, 0.0f, 0.0f };
	float colorValues[3] = { 0.0f, 0.0f, 0.0f };

	bool radioButton1Down = false;
	bool radioButton2Down = false;
	bool radioButton3Down = false;
	bool radioButton4Down = false;

	while (!glfwWindowShouldClose(window)) {
		glfwSwapBuffers(window);
		glClearColor(colorValues[0], colorValues[1], colorValues[2], 1);
		glClear(GL_COLOR_BUFFER_BIT);

		glfwPollEvents();

		ImGui_ImplOpenGL3_NewFrame();
		ImGui_ImplGlfw_NewFrame();
		ImGui::NewFrame();

		ImGui::Begin("An ImGui Panel");

		ImGui::Text("Slider values: %f, %f, %f", sliderValues[0], sliderValues[1], sliderValues[2]);
		ImGui::SliderFloat3("A 3d slider", sliderValues, -10.0f, 10.0f);
		ImGui::ColorPicker3("Color selector", colorValues);

		if (ImGui::CollapsingHeader("a collapsing header")) {
			ImGui::Text("Hello Ryan!");
			ImGui::Text("How are you enjoying the ImGui demo?");
			ImGui::Text("Im trying to take up space right now...");
			ImGui::Text("Not sure what to say..");
			ImGui::Text("Pickles!");

			if (ImGui::Button("A non-suspicious button")) {
				std::cout << "This is some kind of event that is triggered uppon pressing the button" << std::endl;
			}

			static char enteredText[300];
			ImGui::InputText("Enter text: ", enteredText, 300);

			ImGui::NewLine();

			ImGui::Text(enteredText);

		}

		ImGui::End();

		ImGui::Render();
		ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
	}


	ImGui_ImplOpenGL3_Shutdown();
	ImGui_ImplGlfw_Shutdown();
	ImGui::DestroyContext();

	glfwDestroyWindow(window);
	glfwTerminate();

	return 0;
}